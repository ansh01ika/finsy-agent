#!/bin/bash

# Finance Agentic AI (Finsy) - Setup Script
# This script automates the setup process for development and production environments

set -e  # Exit on error

echo "================================"
echo "Finsy Setup Script"
echo "================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}→ $1${NC}"
}

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is not installed. Please install Python 3.11 or higher."
    exit 1
fi

PYTHON_VERSION=$(python3 --version | awk '{print $2}')
print_success "Python $PYTHON_VERSION found"

# Check Python version
REQUIRED_VERSION="3.11"
if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    print_error "Python $REQUIRED_VERSION or higher is required. Current: $PYTHON_VERSION"
    exit 1
fi

# Create virtual environment
print_info "Creating virtual environment..."
python3 -m venv venv
print_success "Virtual environment created"

# Activate virtual environment
print_info "Activating virtual environment..."
source venv/bin/activate
print_success "Virtual environment activated"

# Upgrade pip
print_info "Upgrading pip..."
pip install --upgrade pip
print_success "Pip upgraded"

# Install dependencies
print_info "Installing dependencies..."
pip install -r requirements.txt
print_success "Dependencies installed"

# Create necessary directories
print_info "Creating directories..."
mkdir -p uploads/invoices
mkdir -p uploads/receipts
mkdir -p uploads/documents
mkdir -p logs
mkdir -p data
mkdir -p ml/models
print_success "Directories created"

# Check if .env file exists
if [ ! -f .env ]; then
    print_info "Creating .env file from .env.example..."
    cp .env.example .env
    print_success ".env file created"
    print_info "Please edit .env file with your configuration before running the application"
else
    print_info ".env file already exists"
fi

# Generate secret key if not set
if ! grep -q "SECRET_KEY=your-secret-key" .env || grep -q "SECRET_KEY=your-secret-key" .env; then
    print_info "Generating SECRET_KEY..."
    SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
    sed -i.bak "s/SECRET_KEY=.*/SECRET_KEY=$SECRET_KEY/" .env
    rm .env.bak
    print_success "SECRET_KEY generated"
fi

# Check for Docker
if command -v docker &> /dev/null; then
    print_success "Docker found"
    
    read -p "Do you want to set up with Docker? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # Check for docker-compose
        if command -v docker-compose &> /dev/null; then
            print_success "Docker Compose found"
            
            print_info "Starting Docker services..."
            docker-compose up -d postgres redis mongodb
            print_success "Docker services started"
            
            # Wait for services to be ready
            print_info "Waiting for services to be ready..."
            sleep 10
        else
            print_error "Docker Compose not found. Please install Docker Compose."
        fi
    fi
else
    print_info "Docker not found. Skipping Docker setup."
    print_info "Please ensure PostgreSQL, Redis, and MongoDB are running."
fi

# Initialize database
print_info "Initializing database..."
python3 -c "
from database import init_db
try:
    init_db()
    print('Database initialized successfully')
except Exception as e:
    print(f'Database initialization failed: {e}')
    print('Please ensure your database is running and DATABASE_URL in .env is correct')
"

# Create initial admin user
print_info "Creating initial admin user..."
read -p "Enter admin email: " ADMIN_EMAIL
read -p "Enter admin username: " ADMIN_USERNAME
read -s -p "Enter admin password: " ADMIN_PASSWORD
echo

python3 -c "
from database import get_db_context
from models.database import User, UserRole
from api.routes.auth import get_password_hash

try:
    with get_db_context() as db:
        admin = User(
            email='$ADMIN_EMAIL',
            username='$ADMIN_USERNAME',
            hashed_password=get_password_hash('$ADMIN_PASSWORD'),
            full_name='Admin User',
            role=UserRole.ADMIN,
            is_active=True,
            is_verified=True
        )
        db.add(admin)
        db.commit()
        print('Admin user created successfully')
except Exception as e:
    print(f'Admin user creation failed: {e}')
    print('User may already exist')
"

# Run tests
read -p "Do you want to run tests? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_info "Running tests..."
    pytest tests/ -v
    print_success "Tests completed"
fi

echo ""
echo "================================"
echo "Setup Complete!"
echo "================================"
echo ""
print_success "Finsy has been set up successfully!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your API keys and configuration"
echo "2. Start the application:"
echo "   - Development: python main.py"
echo "   - Production: docker-compose up -d"
echo ""
echo "Access the application at:"
echo "  - API: http://localhost:8000"
echo "  - Docs: http://localhost:8000/api/docs"
echo ""
echo "Default admin credentials:"
echo "  - Email: $ADMIN_EMAIL"
echo "  - Username: $ADMIN_USERNAME"
echo ""
print_info "For more information, see README.md"
echo ""