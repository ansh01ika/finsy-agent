"""
Database Models for Finance Agentic AI (Finsy)
"""
from datetime import datetime
from typing import Optional, List
from decimal import Decimal
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, 
    Text, JSON, ForeignKey, Enum as SQLEnum, Numeric, Index
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum
from uuid import uuid4

Base = declarative_base()


# Enums
class TransactionStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    ON_HOLD = "on_hold"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


class RiskLevel(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DocumentType(str, enum.Enum):
    INVOICE = "invoice"
    RECEIPT = "receipt"
    PURCHASE_ORDER = "purchase_order"
    CONTRACT = "contract"
    STATEMENT = "statement"
    REPORT = "report"


class ApprovalStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    ESCALATED = "escalated"


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    FINANCE_MANAGER = "finance_manager"
    APPROVER = "approver"
    ACCOUNTANT = "accountant"
    AUDITOR = "auditor"
    VIEWER = "viewer"


# Models
class User(Base):
    __tablename__ = "users"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(SQLEnum(UserRole), default=UserRole.VIEWER)
    department = Column(String(100))
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    phone_number = Column(String(20))
    notification_preferences = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime)
    
    # Relationships
    approvals = relationship("Approval", back_populates="approver")
    audit_logs = relationship("AuditLog", back_populates="user")


class Vendor(Base):
    __tablename__ = "vendors"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    vendor_code = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    legal_name = Column(String(255))
    tax_id = Column(String(50))
    email = Column(String(255))
    phone = Column(String(20))
    address = Column(Text)
    country = Column(String(100))
    payment_terms = Column(String(50))
    currency = Column(String(10), default="USD")
    risk_score = Column(Float, default=0.0)
    performance_score = Column(Float, default=0.0)
    total_transactions = Column(Integer, default=0)
    total_amount = Column(Numeric(20, 2), default=0)
    is_active = Column(Boolean, default=True)
    is_blacklisted = Column(Boolean, default=False)
    metadata = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    invoices = relationship("Invoice", back_populates="vendor")
    transactions = relationship("Transaction", back_populates="vendor")


class Invoice(Base):
    __tablename__ = "invoices"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    invoice_number = Column(String(100), unique=True, nullable=False, index=True)
    vendor_id = Column(String(36), ForeignKey("vendors.id"), nullable=False)
    purchase_order_id = Column(String(36), ForeignKey("purchase_orders.id"))
    invoice_date = Column(DateTime, nullable=False)
    due_date = Column(DateTime)
    amount = Column(Numeric(20, 2), nullable=False)
    tax_amount = Column(Numeric(20, 2), default=0)
    total_amount = Column(Numeric(20, 2), nullable=False)
    currency = Column(String(10), default="USD")
    status = Column(SQLEnum(TransactionStatus), default=TransactionStatus.PENDING)
    risk_level = Column(SQLEnum(RiskLevel), default=RiskLevel.LOW)
    risk_score = Column(Float, default=0.0)
    fraud_flags = Column(JSON, default=[])
    line_items = Column(JSON, default=[])
    payment_method = Column(String(50))
    payment_date = Column(DateTime)
    notes = Column(Text)
    document_url = Column(String(500))
    ocr_data = Column(JSON, default={})
    matched_po = Column(Boolean, default=False)
    confidence_score = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    processed_at = Column(DateTime)
    
    # Relationships
    vendor = relationship("Vendor", back_populates="invoices")
    purchase_order = relationship("PurchaseOrder", back_populates="invoices")
    approvals = relationship("Approval", back_populates="invoice")
    transactions = relationship("Transaction", back_populates="invoice")
    
    __table_args__ = (
        Index('ix_invoices_status_date', 'status', 'invoice_date'),
        Index('ix_invoices_vendor_status', 'vendor_id', 'status'),
    )


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    po_number = Column(String(100), unique=True, nullable=False, index=True)
    vendor_id = Column(String(36), ForeignKey("vendors.id"), nullable=False)
    po_date = Column(DateTime, nullable=False)
    expected_delivery_date = Column(DateTime)
    amount = Column(Numeric(20, 2), nullable=False)
    currency = Column(String(10), default="USD")
    status = Column(String(50), default="open")
    line_items = Column(JSON, default=[])
    requester = Column(String(100))
    department = Column(String(100))
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    invoices = relationship("Invoice", back_populates="purchase_order")


class Transaction(Base):
    __tablename__ = "transactions"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    transaction_id = Column(String(100), unique=True, nullable=False, index=True)
    invoice_id = Column(String(36), ForeignKey("invoices.id"))
    vendor_id = Column(String(36), ForeignKey("vendors.id"))
    transaction_type = Column(String(50), nullable=False)  # payment, refund, adjustment
    amount = Column(Numeric(20, 2), nullable=False)
    currency = Column(String(10), default="USD")
    transaction_date = Column(DateTime, default=datetime.utcnow)
    status = Column(SQLEnum(TransactionStatus), default=TransactionStatus.PENDING)
    payment_method = Column(String(50))
    reference_number = Column(String(100))
    bank_account = Column(String(100))
    description = Column(Text)
    metadata = Column(JSON, default={})
    is_reconciled = Column(Boolean, default=False)
    reconciled_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    invoice = relationship("Invoice", back_populates="transactions")
    vendor = relationship("Vendor", back_populates="transactions")
    
    __table_args__ = (
        Index('ix_transactions_date_status', 'transaction_date', 'status'),
    )


class Approval(Base):
    __tablename__ = "approvals"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    invoice_id = Column(String(36), ForeignKey("invoices.id"), nullable=False)
    approver_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    approval_level = Column(Integer, default=1)
    status = Column(SQLEnum(ApprovalStatus), default=ApprovalStatus.PENDING)
    requested_at = Column(DateTime, default=datetime.utcnow)
    responded_at = Column(DateTime)
    comments = Column(Text)
    decision_rationale = Column(Text)
    timeout_at = Column(DateTime)
    is_escalated = Column(Boolean, default=False)
    escalated_to = Column(String(36), ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    invoice = relationship("Invoice", back_populates="approvals")
    approver = relationship("User", foreign_keys=[approver_id], back_populates="approvals")


class FraudAlert(Base):
    __tablename__ = "fraud_alerts"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    entity_type = Column(String(50), nullable=False)  # invoice, transaction, vendor
    entity_id = Column(String(36), nullable=False, index=True)
    alert_type = Column(String(100), nullable=False)
    severity = Column(SQLEnum(RiskLevel), nullable=False)
    fraud_score = Column(Float, nullable=False)
    description = Column(Text)
    evidence = Column(JSON, default={})
    detection_method = Column(String(100))
    status = Column(String(50), default="open")  # open, investigating, resolved, false_positive
    assigned_to = Column(String(36), ForeignKey("users.id"))
    resolved_at = Column(DateTime)
    resolution_notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_fraud_alerts_entity', 'entity_type', 'entity_id'),
        Index('ix_fraud_alerts_status', 'status', 'severity'),
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"))
    action = Column(String(100), nullable=False)
    entity_type = Column(String(50))
    entity_id = Column(String(36))
    old_values = Column(JSON)
    new_values = Column(JSON)
    ip_address = Column(String(50))
    user_agent = Column(String(500))
    metadata = Column(JSON, default={})
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Relationships
    user = relationship("User", back_populates="audit_logs")
    
    __table_args__ = (
        Index('ix_audit_logs_entity', 'entity_type', 'entity_id'),
        Index('ix_audit_logs_user_time', 'user_id', 'timestamp'),
    )


class Document(Base):
    __tablename__ = "documents"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    document_type = Column(SQLEnum(DocumentType), nullable=False)
    entity_type = Column(String(50))
    entity_id = Column(String(36))
    filename = Column(String(255), nullable=False)
    original_filename = Column(String(255))
    file_path = Column(String(500))
    file_size = Column(Integer)
    mime_type = Column(String(100))
    storage_provider = Column(String(50), default="local")
    checksum = Column(String(64))
    is_encrypted = Column(Boolean, default=False)
    ocr_completed = Column(Boolean, default=False)
    ocr_data = Column(JSON, default={})
    metadata = Column(JSON, default={})
    uploaded_by = Column(String(36), ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_documents_entity', 'entity_type', 'entity_id'),
    )


class FinancialReport(Base):
    __tablename__ = "financial_reports"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    report_type = Column(String(100), nullable=False)  # P&L, balance_sheet, cash_flow
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    report_data = Column(JSON, nullable=False)
    format = Column(String(20), default="json")  # json, pdf, excel
    file_path = Column(String(500))
    generated_by = Column(String(50), default="system")
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_reports_type_period', 'report_type', 'period_start', 'period_end'),
    )


class Budget(Base):
    __tablename__ = "budgets"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    department = Column(String(100), nullable=False)
    category = Column(String(100), nullable=False)
    fiscal_year = Column(Integer, nullable=False)
    period = Column(String(20))  # Q1, Q2, monthly
    allocated_amount = Column(Numeric(20, 2), nullable=False)
    spent_amount = Column(Numeric(20, 2), default=0)
    remaining_amount = Column(Numeric(20, 2))
    currency = Column(String(10), default="USD")
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_budgets_dept_year', 'department', 'fiscal_year'),
    )


class ComplianceCheck(Base):
    __tablename__ = "compliance_checks"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid4()))
    entity_type = Column(String(50), nullable=False)
    entity_id = Column(String(36), nullable=False)
    check_type = Column(String(100), nullable=False)
    regulation = Column(String(100))
    status = Column(String(50), default="pending")  # passed, failed, pending
    findings = Column(JSON, default=[])
    severity = Column(String(20))
    checked_at = Column(DateTime, default=datetime.utcnow)
    checked_by = Column(String(50), default="system")
    
    __table_args__ = (
        Index('ix_compliance_entity', 'entity_type', 'entity_id'),
    )