"""
OCR Utilities for Document Processing
Supports Google Cloud Document AI, AWS Textract, Azure Form Recognizer, and Tesseract
"""
from typing import Dict, Any, Optional
import base64
from loguru import logger
from config import settings


def extract_invoice_data(
    file_path: Optional[str] = None,
    base64_data: Optional[str] = None
) -> Dict[str, Any]:
    """
    Extract data from invoice document using available OCR service
    
    Args:
        file_path: Path to document file
        base64_data: Base64 encoded document data
        
    Returns:
        Extracted fields and confidence scores
    """
    try:
        # Try Google Cloud Document AI first
        if settings.GOOGLE_CLOUD_PROJECT and settings.GOOGLE_APPLICATION_CREDENTIALS:
            return _extract_with_google_documentai(file_path, base64_data)
        
        # Try AWS Textract
        elif settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY:
            return _extract_with_aws_textract(file_path, base64_data)
        
        # Try Azure Form Recognizer
        elif settings.AZURE_FORM_RECOGNIZER_ENDPOINT and settings.AZURE_FORM_RECOGNIZER_KEY:
            return _extract_with_azure_form_recognizer(file_path, base64_data)
        
        # Fallback to Tesseract
        else:
            return _extract_with_tesseract(file_path)
    
    except Exception as e:
        logger.error(f"OCR extraction error: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "fields": {},
            "confidence": 0.0
        }


def _extract_with_google_documentai(
    file_path: Optional[str],
    base64_data: Optional[str]
) -> Dict[str, Any]:
    """Extract using Google Cloud Document AI"""
    from google.cloud import documentai_v1 as documentai
    
    try:
        client = documentai.DocumentProcessorServiceClient()
        
        # Read file
        if file_path:
            with open(file_path, "rb") as f:
                content = f.read()
        else:
            content = base64.b64decode(base64_data)
        
        # Process document
        raw_document = documentai.RawDocument(
            content=content,
            mime_type="application/pdf"
        )
        
        request = documentai.ProcessRequest(
            name=f"projects/{settings.GOOGLE_CLOUD_PROJECT}/locations/us/processors/YOUR_PROCESSOR_ID",
            raw_document=raw_document
        )
        
        result = client.process_document(request=request)
        document = result.document
        
        # Extract fields
        fields = {}
        for entity in document.entities:
            fields[entity.type_] = entity.mention_text
        
        return {
            "success": True,
            "fields": {
                "invoice_number": fields.get("invoice_id", ""),
                "invoice_date": fields.get("invoice_date", ""),
                "due_date": fields.get("due_date", ""),
                "amount": _parse_amount(fields.get("total_amount", "0")),
                "tax_amount": _parse_amount(fields.get("tax_amount", "0")),
                "vendor_name": fields.get("supplier_name", ""),
                "line_items": _extract_line_items(document)
            },
            "confidence": document.pages[0].confidence if document.pages else 0.0
        }
    
    except Exception as e:
        logger.error(f"Google Document AI error: {str(e)}")
        raise


def _extract_with_aws_textract(
    file_path: Optional[str],
    base64_data: Optional[str]
) -> Dict[str, Any]:
    """Extract using AWS Textract"""
    import boto3
    
    try:
        client = boto3.client(
            'textract',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            region_name=settings.AWS_REGION
        )
        
        # Read file
        if file_path:
            with open(file_path, "rb") as f:
                content = f.read()
        else:
            content = base64.b64decode(base64_data)
        
        # Analyze document
        response = client.analyze_expense(
            Document={'Bytes': content}
        )
        
        # Extract fields
        fields = {}
        for expense_doc in response.get('ExpenseDocuments', []):
            for field in expense_doc.get('SummaryFields', []):
                field_type = field.get('Type', {}).get('Text', '')
                field_value = field.get('ValueDetection', {}).get('Text', '')
                fields[field_type.lower()] = field_value
        
        return {
            "success": True,
            "fields": {
                "invoice_number": fields.get("invoice_receipt_id", ""),
                "invoice_date": fields.get("invoice_receipt_date", ""),
                "due_date": fields.get("due_date", ""),
                "amount": _parse_amount(fields.get("subtotal", "0")),
                "tax_amount": _parse_amount(fields.get("tax", "0")),
                "total_amount": _parse_amount(fields.get("total", "0")),
                "vendor_name": fields.get("vendor_name", "")
            },
            "confidence": 0.9  # AWS doesn't provide overall confidence
        }
    
    except Exception as e:
        logger.error(f"AWS Textract error: {str(e)}")
        raise


def _extract_with_azure_form_recognizer(
    file_path: Optional[str],
    base64_data: Optional[str]
) -> Dict[str, Any]:
    """Extract using Azure Form Recognizer"""
    from azure.ai.formrecognizer import DocumentAnalysisClient
    from azure.core.credentials import AzureKeyCredential
    
    try:
        client = DocumentAnalysisClient(
            endpoint=settings.AZURE_FORM_RECOGNIZER_ENDPOINT,
            credential=AzureKeyCredential(settings.AZURE_FORM_RECOGNIZER_KEY)
        )
        
        # Read file
        if file_path:
            with open(file_path, "rb") as f:
                content = f.read()
        else:
            content = base64.b64decode(base64_data)
        
        # Analyze invoice
        poller = client.begin_analyze_document(
            "prebuilt-invoice",
            document=content
        )
        result = poller.result()
        
        # Extract first invoice
        if result.documents:
            invoice = result.documents[0]
            fields = invoice.fields
            
            return {
                "success": True,
                "fields": {
                    "invoice_number": fields.get("InvoiceId", {}).get("content", ""),
                    "invoice_date": fields.get("InvoiceDate", {}).get("content", ""),
                    "due_date": fields.get("DueDate", {}).get("content", ""),
                    "amount": _parse_amount(fields.get("SubTotal", {}).get("content", "0")),
                    "tax_amount": _parse_amount(fields.get("TotalTax", {}).get("content", "0")),
                    "total_amount": _parse_amount(fields.get("InvoiceTotal", {}).get("content", "0")),
                    "vendor_name": fields.get("VendorName", {}).get("content", "")
                },
                "confidence": invoice.confidence
            }
        
        return {"success": False, "error": "No invoice found"}
    
    except Exception as e:
        logger.error(f"Azure Form Recognizer error: {str(e)}")
        raise


def _extract_with_tesseract(file_path: str) -> Dict[str, Any]:
    """Extract using Tesseract OCR (fallback)"""
    import pytesseract
    from PIL import Image
    from pdf2image import convert_from_path
    
    try:
        # Convert PDF to images
        if file_path.lower().endswith('.pdf'):
            images = convert_from_path(file_path)
            text = "\n".join([pytesseract.image_to_string(img) for img in images])
        else:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)
        
        # Simple pattern matching (very basic)
        import re
        
        fields = {
            "invoice_number": _extract_pattern(text, r'Invoice\s*#?\s*:?\s*(\S+)'),
            "invoice_date": _extract_pattern(text, r'Date\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})'),
            "amount": _parse_amount(_extract_pattern(text, r'(?:Subtotal|Amount)\s*:?\s*\$?([0-9,]+\.?\d*)'))
        }
        
        return {
            "success": True,
            "fields": fields,
            "confidence": 0.5,  # Low confidence for basic OCR
            "raw_text": text
        }
    
    except Exception as e:
        logger.error(f"Tesseract OCR error: {str(e)}")
        raise


def _parse_amount(amount_str: str) -> float:
    """Parse amount string to float"""
    try:
        # Remove currency symbols and commas
        cleaned = amount_str.replace('$', '').replace(',', '').replace(' ', '').strip()
        return float(cleaned)
    except:
        return 0.0


def _extract_pattern(text: str, pattern: str) -> str:
    """Extract pattern from text"""
    import re
    match = re.search(pattern, text, re.IGNORECASE)
    return match.group(1) if match else ""


def _extract_line_items(document) -> list:
    """Extract line items from document"""
    line_items = []
    # Implementation depends on OCR service structure
    return line_items