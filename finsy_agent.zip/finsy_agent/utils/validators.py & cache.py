"""
Validation and Caching Utilities
"""
from typing import Dict, Any
import re
from datetime import datetime
from decimal import Decimal
import redis
import json
from loguru import logger
from config import settings


# ==================== VALIDATORS ====================

def validate_invoice_data(invoice_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate invoice data
    
    Args:
        invoice_data: Invoice data to validate
        
    Returns:
        Validation result with errors if any
    """
    errors = []
    
    # Required fields
    required_fields = ['invoice_number', 'vendor_id', 'invoice_date', 'amount']
    for field in required_fields:
        if field not in invoice_data or not invoice_data[field]:
            errors.append(f"Missing required field: {field}")
    
    # Validate invoice number format
    if 'invoice_number' in invoice_data:
        if not re.match(r'^[A-Z0-9-]+$', invoice_data['invoice_number']):
            errors.append("Invalid invoice number format")
    
    # Validate dates
    if 'invoice_date' in invoice_data:
        try:
            invoice_date = datetime.fromisoformat(invoice_data['invoice_date'])
            if invoice_date > datetime.now():
                errors.append("Invoice date cannot be in the future")
        except ValueError:
            errors.append("Invalid invoice date format")
    
    if 'due_date' in invoice_data:
        try:
            due_date = datetime.fromisoformat(invoice_data['due_date'])
            invoice_date = datetime.fromisoformat(invoice_data.get('invoice_date', ''))
            if due_date < invoice_date:
                errors.append("Due date cannot be before invoice date")
        except ValueError:
            errors.append("Invalid due date format")
    
    # Validate amounts
    if 'amount' in invoice_data:
        try:
            amount = float(invoice_data['amount'])
            if amount <= 0:
                errors.append("Amount must be positive")
            if amount > 10000000:  # 10 million limit
                errors.append("Amount exceeds maximum allowed")
        except (ValueError, TypeError):
            errors.append("Invalid amount format")
    
    # Validate currency
    valid_currencies = ['USD', 'EUR', 'GBP', 'JPY', 'INR']
    if 'currency' in invoice_data:
        if invoice_data['currency'] not in valid_currencies:
            errors.append(f"Invalid currency. Must be one of: {', '.join(valid_currencies)}")
    
    # Validate email if provided
    if 'email' in invoice_data:
        if not validate_email(invoice_data['email']):
            errors.append("Invalid email format")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors
    }


def validate_email(email: str) -> bool:
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_phone(phone: str) -> bool:
    """Validate phone number format"""
    # Remove common separators
    cleaned = re.sub(r'[\s\-\(\)]', '', phone)
    # Check if it's a valid phone number (10-15 digits)
    return bool(re.match(r'^\+?[1-9]\d{9,14}$', cleaned))


def validate_vendor_data(vendor_data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate vendor data"""
    errors = []
    
    required_fields = ['vendor_code', 'name']
    for field in required_fields:
        if field not in vendor_data or not vendor_data[field]:
            errors.append(f"Missing required field: {field}")
    
    if 'email' in vendor_data and vendor_data['email']:
        if not validate_email(vendor_data['email']):
            errors.append("Invalid email format")
    
    if 'phone' in vendor_data and vendor_data['phone']:
        if not validate_phone(vendor_data['phone']):
            errors.append("Invalid phone format")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors
    }


def sanitize_input(text: str) -> str:
    """Sanitize user input to prevent injection attacks"""
    if not text:
        return ""
    
    # Remove potentially dangerous characters
    sanitized = re.sub(r'[<>"\']', '', text)
    return sanitized.strip()


# ==================== CACHE ====================

class Cache:
    """Redis cache wrapper"""
    
    def __init__(self):
        try:
            self.redis_client = redis.from_url(
                settings.REDIS_URL,
                decode_responses=True
            )
            self.default_expiry = settings.REDIS_CACHE_EXPIRE
            logger.info("Redis cache initialized")
        except Exception as e:
            logger.error(f"Redis initialization error: {str(e)}")
            self.redis_client = None
    
    def get(self, key: str) -> Any:
        """Get value from cache"""
        if not self.redis_client:
            return None
        
        try:
            value = self.redis_client.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.error(f"Cache get error: {str(e)}")
            return None
    
    def set(self, key: str, value: Any, expiry: int = None) -> bool:
        """Set value in cache"""
        if not self.redis_client:
            return False
        
        try:
            expiry = expiry or self.default_expiry
            serialized = json.dumps(value)
            self.redis_client.setex(key, expiry, serialized)
            return True
        except Exception as e:
            logger.error(f"Cache set error: {str(e)}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete value from cache"""
        if not self.redis_client:
            return False
        
        try:
            self.redis_client.delete(key)
            return True
        except Exception as e:
            logger.error(f"Cache delete error: {str(e)}")
            return False
    
    def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        if not self.redis_client:
            return False
        
        try:
            return self.redis_client.exists(key) > 0
        except Exception as e:
            logger.error(f"Cache exists error: {str(e)}")
            return False
    
    def clear_pattern(self, pattern: str) -> int:
        """Clear all keys matching pattern"""
        if not self.redis_client:
            return 0
        
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Cache clear pattern error: {str(e)}")
            return 0
    
    def increment(self, key: str, amount: int = 1) -> int:
        """Increment counter"""
        if not self.redis_client:
            return 0
        
        try:
            return self.redis_client.incrby(key, amount)
        except Exception as e:
            logger.error(f"Cache increment error: {str(e)}")
            return 0
    
    def get_ttl(self, key: str) -> int:
        """Get time to live for key"""
        if not self.redis_client:
            return -1
        
        try:
            return self.redis_client.ttl(key)
        except Exception as e:
            logger.error(f"Cache TTL error: {str(e)}")
            return -1


# Global cache instance
cache = Cache()


async def init_redis():
    """Initialize Redis connection"""
    global cache
    cache = Cache()


def cache_key(prefix: str, *args) -> str:
    """Generate cache key"""
    return f"{prefix}:{':'.join(str(arg) for arg in args)}"


# Cache decorators
def cached(key_prefix: str, expiry: int = None):
    """Decorator to cache function results"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Generate cache key
            key_parts = [key_prefix] + [str(arg) for arg in args]
            key = cache_key(*key_parts)
            
            # Try to get from cache
            cached_value = cache.get(key)
            if cached_value is not None:
                logger.debug(f"Cache hit: {key}")
                return cached_value
            
            # Execute function
            result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
            
            # Store in cache
            cache.set(key, result, expiry)
            logger.debug(f"Cache miss: {key}")
            
            return result
        return wrapper
    return decorator