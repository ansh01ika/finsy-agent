"""
Notification Utilities
Supports Email, Slack, Teams, and SMS notifications
"""
from typing import Optional, Dict, Any
from loguru import logger
from config import settings
import asyncio


async def send_email(
    to_email: str,
    subject: str,
    body: str,
    html: bool = False
) -> bool:
    """Send email notification"""
    try:
        if settings.SENDGRID_API_KEY:
            return await _send_via_sendgrid(to_email, subject, body, html)
        elif settings.SMTP_HOST:
            return await _send_via_smtp(to_email, subject, body, html)
        else:
            logger.warning("No email service configured")
            return False
    except Exception as e:
        logger.error(f"Email sending error: {str(e)}")
        return False


async def _send_via_sendgrid(to_email: str, subject: str, body: str, html: bool) -> bool:
    """Send email via SendGrid"""
    try:
        from sendgrid import SendGridAPIClient
        from sendgrid.helpers.mail import Mail
        
        message = Mail(
            from_email=settings.EMAIL_FROM,
            to_emails=to_email,
            subject=subject,
            html_content=body if html else None,
            plain_text_content=body if not html else None
        )
        
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        response = sg.send(message)
        
        logger.info(f"Email sent to {to_email} via SendGrid")
        return response.status_code in [200, 202]
    
    except Exception as e:
        logger.error(f"SendGrid error: {str(e)}")
        return False


async def _send_via_smtp(to_email: str, subject: str, body: str, html: bool) -> bool:
    """Send email via SMTP"""
    try:
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = settings.EMAIL_FROM
        msg['To'] = to_email
        
        part = MIMEText(body, 'html' if html else 'plain')
        msg.attach(part)
        
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            if settings.SMTP_TLS:
                server.starttls()
            if settings.SMTP_USERNAME and settings.SMTP_PASSWORD:
                server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
            server.send_message(msg)
        
        logger.info(f"Email sent to {to_email} via SMTP")
        return True
    
    except Exception as e:
        logger.error(f"SMTP error: {str(e)}")
        return False


async def send_slack_message(channel: str, message: str, blocks: Optional[list] = None) -> bool:
    """Send Slack notification"""
    try:
        if not settings.SLACK_BOT_TOKEN:
            logger.warning("Slack bot token not configured")
            return False
        
        from slack_sdk import WebClient
        
        client = WebClient(token=settings.SLACK_BOT_TOKEN)
        
        response = client.chat_postMessage(
            channel=channel,
            text=message,
            blocks=blocks
        )
        
        logger.info(f"Slack message sent to {channel}")
        return response["ok"]
    
    except Exception as e:
        logger.error(f"Slack error: {str(e)}")
        return False


async def send_teams_message(message: str, title: Optional[str] = None) -> bool:
    """Send Microsoft Teams notification"""
    try:
        if not settings.TEAMS_WEBHOOK_URL:
            logger.warning("Teams webhook URL not configured")
            return False
        
        import requests
        
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0076D7",
            "title": title or "Finsy Notification",
            "text": message
        }
        
        response = requests.post(
            settings.TEAMS_WEBHOOK_URL,
            json=payload
        )
        
        logger.info("Teams message sent")
        return response.status_code == 200
    
    except Exception as e:
        logger.error(f"Teams error: {str(e)}")
        return False


async def send_sms(phone_number: str, message: str) -> bool:
    """Send SMS notification via Twilio"""
    try:
        if not settings.TWILIO_ACCOUNT_SID:
            logger.warning("Twilio not configured")
            return False
        
        from twilio.rest import Client
        
        client = Client(
            settings.TWILIO_ACCOUNT_SID,
            settings.TWILIO_AUTH_TOKEN
        )
        
        message = client.messages.create(
            body=message,
            from_=settings.TWILIO_PHONE_NUMBER,
            to=phone_number
        )
        
        logger.info(f"SMS sent to {phone_number}")
        return message.sid is not None
    
    except Exception as e:
        logger.error(f"Twilio error: {str(e)}")
        return False


# High-level notification functions
async def send_approval_notification(
    approver_email: str,
    invoice: Any,
    approval: Any
) -> bool:
    """Send approval request notification"""
    subject = f"Approval Required: Invoice {invoice.invoice_number if invoice else 'N/A'}"
    body = f"""
    <h2>Approval Request</h2>
    <p>An invoice requires your approval.</p>
    
    <p><strong>Invoice Number:</strong> {invoice.invoice_number if invoice else 'N/A'}</p>
    <p><strong>Amount:</strong> ${invoice.total_amount if invoice else 0}</p>
    <p><strong>Approval Level:</strong> {approval.approval_level}</p>
    <p><strong>Timeout:</strong> {approval.timeout_at.strftime('%Y-%m-%d %H:%M') if approval.timeout_at else 'N/A'}</p>
    
    <p>Please review and approve or reject this invoice.</p>
    """
    
    return await send_email(approver_email, subject, body, html=True)


async def send_escalation_notification(
    escalation_email: str,
    original_approval: Any,
    new_approval: Any
) -> bool:
    """Send escalation notification"""
    subject = "Approval Escalated to You"
    body = f"""
    <h2>Approval Escalation</h2>
    <p>An approval has been escalated to you.</p>
    
    <p><strong>Original Approver:</strong> Level {original_approval.approval_level}</p>
    <p><strong>Your Level:</strong> {new_approval.approval_level}</p>
    
    <p>Please review this escalated approval request.</p>
    """
    
    return await send_email(escalation_email, subject, body, html=True)


async def send_fraud_alert(
    recipient_email: str,
    alert_details: Dict[str, Any]
) -> bool:
    """Send fraud alert notification"""
    subject = f"URGENT: Fraud Alert - {alert_details.get('entity_type', 'Unknown')}"
    body = f"""
    <h2 style="color: red;">Fraud Alert</h2>
    <p><strong>Entity Type:</strong> {alert_details.get('entity_type')}</p>
    <p><strong>Entity ID:</strong> {alert_details.get('entity_id')}</p>
    <p><strong>Fraud Score:</strong> {alert_details.get('fraud_score', 0):.2f}</p>
    <p><strong>Severity:</strong> {alert_details.get('severity', 'Unknown')}</p>
    
    <p>Immediate investigation required.</p>
    """
    
    # Send via multiple channels for critical alerts
    await send_email(recipient_email, subject, body, html=True)
    
    if settings.SLACK_BOT_TOKEN:
        await send_slack_message(
            "#fraud-alerts",
            f"🚨 Fraud Alert: {alert_details.get('entity_type')} - Score: {alert_details.get('fraud_score', 0):.2f}"
        )
    
    return True


async def send_payment_notification(
    recipient_email: str,
    payment_details: Dict[str, Any]
) -> bool:
    """Send payment completion notification"""
    subject = f"Payment Processed: {payment_details.get('reference_number', 'N/A')}"
    body = f"""
    <h2>Payment Confirmation</h2>
    <p>A payment has been processed.</p>
    
    <p><strong>Reference:</strong> {payment_details.get('reference_number')}</p>
    <p><strong>Amount:</strong> ${payment_details.get('amount', 0)}</p>
    <p><strong>Vendor:</strong> {payment_details.get('vendor_name', 'N/A')}</p>
    <p><strong>Date:</strong> {payment_details.get('date', 'N/A')}</p>
    """
    
    return await send_email(recipient_email, subject, body, html=True)