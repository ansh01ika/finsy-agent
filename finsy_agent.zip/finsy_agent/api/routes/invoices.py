"""
Invoice API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
from decimal import Decimal

from database import get_db
from models.database import Invoice, User, UserRole, TransactionStatus, RiskLevel
from api.routes.auth import get_current_active_user, check_permission
from agents.finance_agent import finsy_agent

router = APIRouter()


# Pydantic models
class InvoiceCreate(BaseModel):
    invoice_number: str
    vendor_id: str
    po_number: Optional[str] = None
    invoice_date: str
    due_date: Optional[str] = None
    amount: float
    tax_amount: Optional[float] = 0
    currency: str = "USD"
    line_items: Optional[List[dict]] = []
    notes: Optional[str] = None


class InvoiceResponse(BaseModel):
    id: str
    invoice_number: str
    vendor_id: str
    invoice_date: datetime
    due_date: Optional[datetime]
    amount: Decimal
    tax_amount: Decimal
    total_amount: Decimal
    currency: str
    status: TransactionStatus
    risk_level: RiskLevel
    risk_score: float
    matched_po: bool
    confidence_score: float
    created_at: datetime
    
    class Config:
        from_attributes = True


class InvoiceProcessRequest(BaseModel):
    invoice_data: dict
    auto_process: bool = True


# API Routes
@router.post("/", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_invoice(
    invoice: InvoiceCreate,
    current_user: User = Depends(check_permission(UserRole.ACCOUNTANT)),
    db: Session = Depends(get_db)
):
    """Create and process new invoice"""
    # Use agent to process invoice
    result = finsy_agent.invoice_tool.process_invoice(invoice.dict())
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=result.get("validation_errors", ["Processing failed"])
        )
    
    return result


@router.post("/upload", response_model=dict)
async def upload_invoice(
    file: UploadFile = File(...),
    vendor_id: Optional[str] = None,
    current_user: User = Depends(check_permission(UserRole.ACCOUNTANT)),
    db: Session = Depends(get_db)
):
    """Upload invoice document for processing"""
    # Save file temporarily
    import os
    from pathlib import Path
    
    upload_dir = Path(settings.UPLOAD_DIR) / "invoices"
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    file_path = upload_dir / f"{datetime.utcnow().timestamp()}_{file.filename}"
    
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    
    # Process invoice with OCR
    invoice_data = {
        "document_path": str(file_path),
        "vendor_id": vendor_id
    }
    
    result = finsy_agent.invoice_tool.process_invoice(invoice_data)
    
    return result


@router.get("/", response_model=List[InvoiceResponse])
async def list_invoices(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    status: Optional[TransactionStatus] = None,
    risk_level: Optional[RiskLevel] = None,
    vendor_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List invoices with filters"""
    query = db.query(Invoice)
    
    if status:
        query = query.filter(Invoice.status == status)
    if risk_level:
        query = query.filter(Invoice.risk_level == risk_level)
    if vendor_id:
        query = query.filter(Invoice.vendor_id == vendor_id)
    
    invoices = query.offset(skip).limit(limit).all()
    
    return invoices


@router.get("/{invoice_id}", response_model=InvoiceResponse)
async def get_invoice(
    invoice_id: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get invoice by ID"""
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invoice not found"
        )
    
    return invoice


@router.post("/{invoice_id}/fraud-check")
async def check_invoice_fraud(
    invoice_id: str,
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Run fraud detection on invoice"""
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invoice not found"
        )
    
    result = finsy_agent.fraud_tool.detect_fraud("invoice", invoice_id)
    
    return result


@router.delete("/{invoice_id}")
async def delete_invoice(
    invoice_id: str,
    current_user: User = Depends(check_permission(UserRole.FINANCE_MANAGER)),
    db: Session = Depends(get_db)
):
    """Delete invoice (soft delete)"""
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invoice not found"
        )
    
    # Soft delete by changing status
    invoice.status = TransactionStatus.CANCELLED
    invoice.updated_at = datetime.utcnow()
    db.commit()
    
    return {"message": "Invoice cancelled successfully"}


@router.get("/{invoice_id}/history")
async def get_invoice_history(
    invoice_id: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get invoice processing history and audit trail"""
    from models.database import AuditLog
    
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invoice not found"
        )
    
    # Get audit logs
    audit_logs = db.query(AuditLog).filter(
        AuditLog.entity_type == "invoice",
        AuditLog.entity_id == invoice_id
    ).order_by(AuditLog.timestamp.desc()).all()
    
    return {
        "invoice_id": invoice_id,
        "current_status": invoice.status.value,
        "audit_trail": [
            {
                "action": log.action,
                "user_id": log.user_id,
                "timestamp": log.timestamp.isoformat(),
                "metadata": log.metadata
            }
            for log in audit_logs
        ]
    }


@router.post("/{invoice_id}/reprocess")
async def reprocess_invoice(
    invoice_id: str,
    current_user: User = Depends(check_permission(UserRole.FINANCE_MANAGER)),
    db: Session = Depends(get_db)
):
    """Reprocess an invoice"""
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invoice not found"
        )
    
    # Prepare invoice data for reprocessing
    invoice_data = {
        "invoice_number": invoice.invoice_number,
        "vendor_id": invoice.vendor_id,
        "invoice_date": invoice.invoice_date.isoformat(),
        "amount": float(invoice.amount),
        "tax_amount": float(invoice.tax_amount),
        "currency": invoice.currency,
        "document_url": invoice.document_url
    }
    
    result = finsy_agent.invoice_tool.process_invoice(invoice_data)
    
    return result