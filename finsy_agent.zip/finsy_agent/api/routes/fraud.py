"""
Fraud Detection API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

from database import get_db
from models.database import FraudAlert, User, UserRole, RiskLevel
from api.routes.auth import get_current_active_user, check_permission
from agents.finance_agent import finsy_agent

router = APIRouter()


# Pydantic models
class FraudCheckRequest(BaseModel):
    entity_type: str  # invoice, transaction, vendor
    entity_id: str


class FraudAlertResponse(BaseModel):
    id: str
    entity_type: str
    entity_id: str
    alert_type: str
    severity: RiskLevel
    fraud_score: float
    description: Optional[str]
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class FraudAlertUpdate(BaseModel):
    status: str  # investigating, resolved, false_positive
    resolution_notes: Optional[str] = None
    assigned_to: Optional[str] = None


@router.post("/check")
async def check_for_fraud(
    request: FraudCheckRequest,
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Run fraud detection on entity"""
    result = finsy_agent.fraud_tool.detect_fraud(
        request.entity_type,
        request.entity_id
    )
    
    return result


@router.get("/alerts", response_model=List[FraudAlertResponse])
async def list_fraud_alerts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    status: Optional[str] = None,
    severity: Optional[RiskLevel] = None,
    entity_type: Optional[str] = None,
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """List fraud alerts with filters"""
    query = db.query(FraudAlert)
    
    if status:
        query = query.filter(FraudAlert.status == status)
    if severity:
        query = query.filter(FraudAlert.severity == severity)
    if entity_type:
        query = query.filter(FraudAlert.entity_type == entity_type)
    
    alerts = query.order_by(
        FraudAlert.created_at.desc()
    ).offset(skip).limit(limit).all()
    
    return alerts


@router.get("/alerts/{alert_id}", response_model=FraudAlertResponse)
async def get_fraud_alert(
    alert_id: str,
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Get fraud alert details"""
    alert = db.query(FraudAlert).filter(FraudAlert.id == alert_id).first()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Fraud alert not found"
        )
    
    return alert


@router.put("/alerts/{alert_id}")
async def update_fraud_alert(
    alert_id: str,
    update: FraudAlertUpdate,
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Update fraud alert status"""
    alert = db.query(FraudAlert).filter(FraudAlert.id == alert_id).first()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Fraud alert not found"
        )
    
    alert.status = update.status
    
    if update.resolution_notes:
        alert.resolution_notes = update.resolution_notes
    
    if update.assigned_to:
        alert.assigned_to = update.assigned_to
    
    if update.status in ["resolved", "false_positive"]:
        alert.resolved_at = datetime.utcnow()
    
    db.commit()
    db.refresh(alert)
    
    return {
        "message": "Fraud alert updated successfully",
        "alert_id": alert_id,
        "status": alert.status
    }


@router.get("/dashboard/summary")
async def get_fraud_dashboard_summary(
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Get fraud detection dashboard summary"""
    from sqlalchemy import func
    from datetime import timedelta
    
    now = datetime.utcnow()
    last_30_days = now - timedelta(days=30)
    
    # Total alerts
    total_alerts = db.query(func.count(FraudAlert.id)).scalar()
    
    # Alerts in last 30 days
    recent_alerts = db.query(func.count(FraudAlert.id)).filter(
        FraudAlert.created_at >= last_30_days
    ).scalar()
    
    # Open alerts
    open_alerts = db.query(func.count(FraudAlert.id)).filter(
        FraudAlert.status == "open"
    ).scalar()
    
    # Alerts by severity
    severity_breakdown = db.query(
        FraudAlert.severity,
        func.count(FraudAlert.id)
    ).group_by(FraudAlert.severity).all()
    
    # Alerts by entity type
    entity_breakdown = db.query(
        FraudAlert.entity_type,
        func.count(FraudAlert.id)
    ).group_by(FraudAlert.entity_type).all()
    
    # Average fraud score
    avg_fraud_score = db.query(
        func.avg(FraudAlert.fraud_score)
    ).scalar() or 0.0
    
    return {
        "total_alerts": total_alerts,
        "recent_alerts_30_days": recent_alerts,
        "open_alerts": open_alerts,
        "average_fraud_score": float(avg_fraud_score),
        "severity_breakdown": {
            severity.value: count for severity, count in severity_breakdown
        },
        "entity_breakdown": {
            entity_type: count for entity_type, count in entity_breakdown
        }
    }


@router.get("/patterns/analysis")
async def analyze_fraud_patterns(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Analyze fraud patterns over time"""
    from datetime import timedelta
    from sqlalchemy import func
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Get alerts over time
    alerts_over_time = db.query(
        func.date(FraudAlert.created_at).label('date'),
        func.count(FraudAlert.id).label('count')
    ).filter(
        FraudAlert.created_at >= start_date
    ).group_by(
        func.date(FraudAlert.created_at)
    ).all()
    
    # Common alert types
    alert_types = db.query(
        FraudAlert.alert_type,
        func.count(FraudAlert.id).label('count')
    ).filter(
        FraudAlert.created_at >= start_date
    ).group_by(
        FraudAlert.alert_type
    ).order_by(
        func.count(FraudAlert.id).desc()
    ).limit(10).all()
    
    return {
        "period_days": days,
        "alerts_over_time": [
            {"date": str(date), "count": count}
            for date, count in alerts_over_time
        ],
        "top_alert_types": [
            {"type": alert_type, "count": count}
            for alert_type, count in alert_types
        ]
    }


@router.post("/bulk-check")
async def bulk_fraud_check(
    entity_ids: List[str],
    entity_type: str,
    current_user: User = Depends(check_permission(UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    """Run fraud detection on multiple entities"""
    results = []
    
    for entity_id in entity_ids:
        try:
            result = finsy_agent.fraud_tool.detect_fraud(entity_type, entity_id)
            results.append({
                "entity_id": entity_id,
                "success": result.get("success", False),
                "fraud_score": result.get("fraud_score", 0),
                "risk_level": result.get("risk_level", "unknown")
            })
        except Exception as e:
            results.append({
                "entity_id": entity_id,
                "success": False,
                "error": str(e)
            })
    
    return {
        "total_checked": len(entity_ids),
        "results": results
    }