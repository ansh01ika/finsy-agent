"""
Vendor Management API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, EmailStr
from datetime import datetime
from decimal import Decimal

from database import get_db
from models.database import Vendor, Invoice, User, UserRole
from api.routes.auth import get_current_active_user, check_permission
from agents.finance_agent import finsy_agent

router = APIRouter()


# Pydantic models
class VendorCreate(BaseModel):
    vendor_code: str
    name: str
    legal_name: Optional[str] = None
    tax_id: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    country: Optional[str] = None
    payment_terms: Optional[str] = None
    currency: str = "USD"


class VendorUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    payment_terms: Optional[str] = None
    is_active: Optional[bool] = None


class VendorResponse(BaseModel):
    id: str
    vendor_code: str
    name: str
    email: Optional[str]
    phone: Optional[str]
    country: Optional[str]
    payment_terms: Optional[str]
    currency: str
    risk_score: float
    performance_score: float
    total_transactions: int
    total_amount: Decimal
    is_active: bool
    is_blacklisted: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


# API Routes
@router.post("/", response_model=VendorResponse, status_code=status.HTTP_201_CREATED)
async def create_vendor(
    vendor: VendorCreate,
    current_user: User = Depends(check_permission(UserRole.ACCOUNTANT)),
    db: Session = Depends(get_db)
):
    """Create new vendor"""
    # Check if vendor code already exists
    existing = db.query(Vendor).filter(Vendor.vendor_code == vendor.vendor_code).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Vendor code already exists"
        )
    
    new_vendor = Vendor(**vendor.dict())
    db.add(new_vendor)
    db.commit()
    db.refresh(new_vendor)
    
    return new_vendor


@router.get("/", response_model=List[VendorResponse])
async def list_vendors(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    is_active: Optional[bool] = None,
    country: Optional[str] = None,
    search: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List vendors with filters"""
    query = db.query(Vendor)
    
    if is_active is not None:
        query = query.filter(Vendor.is_active == is_active)
    if country:
        query = query.filter(Vendor.country == country)
    if search:
        query = query.filter(
            (Vendor.name.ilike(f"%{search}%")) |
            (Vendor.vendor_code.ilike(f"%{search}%"))
        )
    
    vendors = query.offset(skip).limit(limit).all()
    return vendors


@router.get("/{vendor_id}", response_model=VendorResponse)
async def get_vendor(
    vendor_id: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get vendor by ID"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    return vendor


@router.put("/{vendor_id}", response_model=VendorResponse)
async def update_vendor(
    vendor_id: str,
    vendor_update: VendorUpdate,
    current_user: User = Depends(check_permission(UserRole.ACCOUNTANT)),
    db: Session = Depends(get_db)
):
    """Update vendor information"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    update_data = vendor_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(vendor, key, value)
    
    vendor.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(vendor)
    
    return vendor


@router.delete("/{vendor_id}")
async def delete_vendor(
    vendor_id: str,
    current_user: User = Depends(check_permission(UserRole.FINANCE_MANAGER)),
    db: Session = Depends(get_db)
):
    """Deactivate vendor (soft delete)"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    vendor.is_active = False
    vendor.updated_at = datetime.utcnow()
    db.commit()
    
    return {"message": "Vendor deactivated successfully"}


@router.post("/{vendor_id}/evaluate")
async def evaluate_vendor(
    vendor_id: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Evaluate vendor performance and risk"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    result = finsy_agent.vendor_tool.evaluate_vendor(vendor_id)
    return result


@router.get("/{vendor_id}/invoices", response_model=List[dict])
async def get_vendor_invoices(
    vendor_id: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all invoices for a vendor"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    invoices = db.query(Invoice).filter(
        Invoice.vendor_id == vendor_id
    ).offset(skip).limit(limit).all()
    
    return [
        {
            "id": inv.id,
            "invoice_number": inv.invoice_number,
            "invoice_date": inv.invoice_date.isoformat(),
            "amount": float(inv.total_amount),
            "status": inv.status.value,
            "risk_level": inv.risk_level.value
        }
        for inv in invoices
    ]


@router.get("/{vendor_id}/statistics")
async def get_vendor_statistics(
    vendor_id: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get vendor statistics and analytics"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    from sqlalchemy import func
    from models.database import TransactionStatus
    
    # Get invoice statistics
    invoice_stats = db.query(
        func.count(Invoice.id).label('total_invoices'),
        func.sum(Invoice.total_amount).label('total_amount'),
        func.avg(Invoice.total_amount).label('avg_amount')
    ).filter(Invoice.vendor_id == vendor_id).first()
    
    # Get status breakdown
    status_breakdown = db.query(
        Invoice.status,
        func.count(Invoice.id).label('count')
    ).filter(Invoice.vendor_id == vendor_id).group_by(Invoice.status).all()
    
    return {
        "vendor_id": vendor_id,
        "vendor_name": vendor.name,
        "total_invoices": invoice_stats.total_invoices or 0,
        "total_amount": float(invoice_stats.total_amount or 0),
        "average_invoice_amount": float(invoice_stats.avg_amount or 0),
        "risk_score": vendor.risk_score,
        "performance_score": vendor.performance_score,
        "status_breakdown": {
            status.value: count for status, count in status_breakdown
        }
    }


@router.post("/{vendor_id}/blacklist")
async def blacklist_vendor(
    vendor_id: str,
    reason: str,
    current_user: User = Depends(check_permission(UserRole.FINANCE_MANAGER)),
    db: Session = Depends(get_db)
):
    """Blacklist a vendor"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    vendor.is_blacklisted = True
    vendor.is_active = False
    vendor.metadata = vendor.metadata or {}
    vendor.metadata['blacklist_reason'] = reason
    vendor.metadata['blacklisted_by'] = current_user.id
    vendor.metadata['blacklisted_at'] = datetime.utcnow().isoformat()
    vendor.updated_at = datetime.utcnow()
    
    db.commit()
    
    return {"message": "Vendor blacklisted successfully", "reason": reason}


@router.delete("/{vendor_id}/blacklist")
async def remove_vendor_from_blacklist(
    vendor_id: str,
    current_user: User = Depends(check_permission(UserRole.FINANCE_MANAGER)),
    db: Session = Depends(get_db)
):
    """Remove vendor from blacklist"""
    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
    
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found"
        )
    
    vendor.is_blacklisted = False
    vendor.updated_at = datetime.utcnow()
    db.commit()
    
    return {"message": "Vendor removed from blacklist"}