"""
Machine Learning Models for Fraud Detection and Risk Analysis
"""
import numpy as np
from typing import List, Dict, Any
from loguru import logger
import joblib
from pathlib import Path


class FraudDetectionModel:
    """
    ML Model for fraud detection
    Uses ensemble of models for better accuracy
    """
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_names = [
            'amount',
            'amount_zscore',
            'vendor_risk_score',
            'invoice_age_days',
            'duplicate_count',
            'po_matched',
            'ocr_confidence',
            'payment_term_violation',
            'amount_variance_from_avg',
            'transaction_velocity'
        ]
        self.model_path = Path("ml/models/fraud_detector.pkl")
        self.scaler_path = Path("ml/models/scaler.pkl")
    
    def load_model(self):
        """Load pre-trained model"""
        try:
            if self.model_path.exists():
                self.model = joblib.load(self.model_path)
                logger.info("Fraud detection model loaded")
            else:
                logger.warning("Fraud model not found, using rule-based detection")
                self.model = None
            
            if self.scaler_path.exists():
                self.scaler = joblib.load(self.scaler_path)
        except Exception as e:
            logger.error(f"Model loading error: {str(e)}")
            self.model = None
    
    def predict_proba(self, features: List[List[float]]) -> np.ndarray:
        """
        Predict fraud probability
        
        Args:
            features: Feature matrix
            
        Returns:
            Probability matrix [prob_not_fraud, prob_fraud]
        """
        try:
            if self.model is None:
                # Fallback to rule-based prediction
                return self._rule_based_prediction(features)
            
            # Scale features
            if self.scaler:
                features_scaled = self.scaler.transform(features)
            else:
                features_scaled = features
            
            # Get predictions
            probabilities = self.model.predict_proba(features_scaled)
            
            return probabilities
        
        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            return np.array([[0.5, 0.5]])  # Default uncertain prediction
    
    def _rule_based_prediction(self, features: List[List[float]]) -> np.ndarray:
        """
        Rule-based fraud detection (fallback)
        
        Args:
            features: Feature matrix
            
        Returns:
            Probability matrix
        """
        predictions = []
        
        for feature_row in features:
            score = 0.0
            
            # Rule 1: High amount
            if feature_row[0] > 50000:
                score += 0.3
            
            # Rule 2: High vendor risk
            if feature_row[2] > 0.7:
                score += 0.3
            
            # Rule 3: Duplicates found
            if feature_row[4] > 0:
                score += 0.25
            
            # Rule 4: No PO match
            if feature_row[5] == 0:
                score += 0.15
            
            # Rule 5: Low OCR confidence
            if feature_row[6] < 0.7:
                score += 0.1
            
            fraud_prob = min(score, 1.0)
            predictions.append([1.0 - fraud_prob, fraud_prob])
        
        return np.array(predictions)
    
    def train(self, X_train, y_train):
        """
        Train the fraud detection model
        
        Args:
            X_train: Training features
            y_train: Training labels
        """
        try:
            from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
            from sklearn.preprocessing import StandardScaler
            from sklearn.model_selection import cross_val_score
            
            # Scale features
            self.scaler = StandardScaler()
            X_scaled = self.scaler.fit_transform(X_train)
            
            # Train ensemble model
            rf_model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42
            )
            
            gb_model = GradientBoostingClassifier(
                n_estimators=100,
                max_depth=5,
                random_state=42
            )
            
            # Use Random Forest as primary model
            self.model = rf_model
            self.model.fit(X_scaled, y_train)
            
            # Evaluate
            scores = cross_val_score(self.model, X_scaled, y_train, cv=5)
            logger.info(f"Model trained with CV score: {scores.mean():.4f}")
            
            # Save model
            self.save_model()
            
            return {
                "success": True,
                "cv_score": scores.mean(),
                "cv_std": scores.std()
            }
        
        except Exception as e:
            logger.error(f"Training error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def save_model(self):
        """Save trained model"""
        try:
            self.model_path.parent.mkdir(parents=True, exist_ok=True)
            
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)
            
            logger.info("Model saved successfully")
        except Exception as e:
            logger.error(f"Model saving error: {str(e)}")
    
    def extract_features(self, invoice_data: Dict[str, Any]) -> List[float]:
        """
        Extract features from invoice data
        
        Args:
            invoice_data: Invoice data dictionary
            
        Returns:
            Feature vector
        """
        features = [
            float(invoice_data.get('amount', 0)),
            float(invoice_data.get('amount_zscore', 0)),
            float(invoice_data.get('vendor_risk_score', 0)),
            float(invoice_data.get('invoice_age_days', 0)),
            float(invoice_data.get('duplicate_count', 0)),
            1.0 if invoice_data.get('po_matched', False) else 0.0,
            float(invoice_data.get('ocr_confidence', 1.0)),
            1.0 if invoice_data.get('payment_term_violation', False) else 0.0,
            float(invoice_data.get('amount_variance_from_avg', 0)),
            float(invoice_data.get('transaction_velocity', 0))
        ]
        
        return features


class RiskScoringModel:
    """Model for risk scoring"""
    
    def __init__(self):
        self.weights = {
            'amount': 0.25,
            'vendor_history': 0.20,
            'payment_terms': 0.15,
            'documentation': 0.15,
            'compliance': 0.15,
            'market_factors': 0.10
        }
    
    def calculate_risk_score(self, factors: Dict[str, float]) -> float:
        """
        Calculate weighted risk score
        
        Args:
            factors: Dictionary of risk factors
            
        Returns:
            Risk score between 0 and 1
        """
        total_score = 0.0
        
        for factor, weight in self.weights.items():
            factor_score = factors.get(factor, 0.0)
            total_score += factor_score * weight
        
        return min(max(total_score, 0.0), 1.0)


# Global model instances
fraud_detection_model = FraudDetectionModel()
risk_scoring_model = RiskScoringModel()


def load_fraud_detection_model():
    """Load fraud detection model on startup"""
    fraud_detection_model.load_model()


def get_fraud_model():
    """Get fraud detection model instance"""
    return fraud_detection_model


def get_risk_model():
    """Get risk scoring model instance"""
    return risk_scoring_model