"""
Invoice Processing Tool
Handles invoice validation, OCR, PO matching, and processing
"""
from typing import Dict, Any, Optional, List
from datetime import datetime
from decimal import Decimal
from loguru import logger
import re

from database import get_db_context
from models.database import Invoice, PurchaseOrder, Vendor, Document
from utils.ocr import extract_invoice_data
from utils.validators import validate_invoice_data
from config import settings


class InvoiceProcessingTool:
    """Tool for processing invoices end-to-end"""
    
    def __init__(self):
        self.confidence_threshold = settings.AUTO_APPROVE_CONFIDENCE
        self.auto_approve_amount = settings.AUTO_APPROVE_THRESHOLD
    
    def process_invoice(self, invoice_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process an invoice through the complete workflow
        
        Steps:
        1. Validate input data
        2. Extract data if document provided
        3. Match with PO if available
        4. Validate vendor
        5. Calculate risk score
        6. Determine approval requirements
        
        Args:
            invoice_data: Invoice information
            
        Returns:
            Processing result with status and next steps
        """
        try:
            result = {
                "success": False,
                "invoice_id": None,
                "status": "pending",
                "validation_errors": [],
                "warnings": [],
                "next_steps": []
            }
            
            # Step 1: Extract data from document if provided
            if "document_path" in invoice_data or "document_base64" in invoice_data:
                ocr_result = self._extract_invoice_data(invoice_data)
                if not ocr_result["success"]:
                    result["validation_errors"].append("OCR extraction failed")
                    return result
                
                # Merge extracted data with provided data
                invoice_data.update(ocr_result["data"])
                result["ocr_confidence"] = ocr_result.get("confidence", 0)
            
            # Step 2: Validate invoice data
            validation_result = validate_invoice_data(invoice_data)
            if not validation_result["valid"]:
                result["validation_errors"] = validation_result["errors"]
                return result
            
            # Step 3: Check for duplicates
            duplicate_check = self._check_duplicate_invoice(
                invoice_data.get("invoice_number"),
                invoice_data.get("vendor_id")
            )
            if duplicate_check["is_duplicate"]:
                result["validation_errors"].append(
                    f"Duplicate invoice found: {duplicate_check['existing_id']}"
                )
                result["warnings"].append("This invoice may have already been processed")
                return result
            
            # Step 4: Match with Purchase Order
            po_match_result = self._match_purchase_order(invoice_data)
            invoice_data["matched_po"] = po_match_result["matched"]
            invoice_data["po_id"] = po_match_result.get("po_id")
            invoice_data["po_match_confidence"] = po_match_result.get("confidence", 0)
            
            if not po_match_result["matched"]:
                result["warnings"].append("No matching purchase order found")
            
            # Step 5: Validate vendor
            vendor_result = self._validate_vendor(invoice_data.get("vendor_id"))
            if not vendor_result["valid"]:
                result["validation_errors"].append(vendor_result["message"])
                return result
            
            invoice_data["vendor_risk_score"] = vendor_result.get("risk_score", 0)
            
            # Step 6: Calculate total amounts
            invoice_data = self._calculate_amounts(invoice_data)
            
            # Step 7: Determine risk level
            risk_assessment = self._assess_risk(invoice_data)
            invoice_data["risk_level"] = risk_assessment["risk_level"]
            invoice_data["risk_score"] = risk_assessment["risk_score"]
            invoice_data["risk_factors"] = risk_assessment["factors"]
            
            # Step 8: Create invoice in database
            with get_db_context() as db:
                invoice = Invoice(
                    invoice_number=invoice_data["invoice_number"],
                    vendor_id=invoice_data["vendor_id"],
                    purchase_order_id=invoice_data.get("po_id"),
                    invoice_date=datetime.fromisoformat(invoice_data["invoice_date"]),
                    due_date=datetime.fromisoformat(invoice_data.get("due_date")) if invoice_data.get("due_date") else None,
                    amount=Decimal(str(invoice_data["amount"])),
                    tax_amount=Decimal(str(invoice_data.get("tax_amount", 0))),
                    total_amount=Decimal(str(invoice_data["total_amount"])),
                    currency=invoice_data.get("currency", "USD"),
                    line_items=invoice_data.get("line_items", []),
                    matched_po=invoice_data["matched_po"],
                    confidence_score=invoice_data.get("ocr_confidence", 1.0),
                    risk_level=invoice_data["risk_level"],
                    risk_score=invoice_data["risk_score"],
                    fraud_flags=risk_assessment["factors"],
                    notes=invoice_data.get("notes"),
                    document_url=invoice_data.get("document_path")
                )
                
                db.add(invoice)
                db.commit()
                db.refresh(invoice)
                
                result["invoice_id"] = invoice.id
                result["success"] = True
            
            # Step 9: Determine next steps
            result["next_steps"] = self._determine_next_steps(invoice_data)
            result["status"] = self._determine_status(invoice_data)
            result["requires_approval"] = self._requires_approval(invoice_data)
            
            logger.info(f"Invoice processed successfully: {invoice_data['invoice_number']}")
            
            return result
            
        except Exception as e:
            logger.error(f"Invoice processing error: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "validation_errors": [str(e)]
            }
    
    def _extract_invoice_data(self, invoice_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract data from invoice document using OCR"""
        try:
            if "document_path" in invoice_data:
                extracted = extract_invoice_data(invoice_data["document_path"])
            elif "document_base64" in invoice_data:
                extracted = extract_invoice_data(
                    base64_data=invoice_data["document_base64"]
                )
            else:
                return {"success": False, "error": "No document provided"}
            
            return {
                "success": True,
                "data": extracted["fields"],
                "confidence": extracted.get("confidence", 0)
            }
        except Exception as e:
            logger.error(f"OCR extraction error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _check_duplicate_invoice(
        self, 
        invoice_number: str, 
        vendor_id: str
    ) -> Dict[str, Any]:
        """Check if invoice already exists"""
        try:
            with get_db_context() as db:
                existing = db.query(Invoice).filter(
                    Invoice.invoice_number == invoice_number,
                    Invoice.vendor_id == vendor_id
                ).first()
                
                if existing:
                    return {
                        "is_duplicate": True,
                        "existing_id": existing.id,
                        "existing_status": existing.status.value
                    }
                
                return {"is_duplicate": False}
        except Exception as e:
            logger.error(f"Duplicate check error: {str(e)}")
            return {"is_duplicate": False}
    
    def _match_purchase_order(self, invoice_data: Dict[str, Any]) -> Dict[str, Any]:
        """Match invoice with purchase order"""
        try:
            # Check if PO number provided
            po_number = invoice_data.get("po_number")
            if not po_number:
                return {"matched": False, "confidence": 0}
            
            with get_db_context() as db:
                po = db.query(PurchaseOrder).filter(
                    PurchaseOrder.po_number == po_number,
                    PurchaseOrder.vendor_id == invoice_data.get("vendor_id")
                ).first()
                
                if not po:
                    return {"matched": False, "confidence": 0}
                
                # Check amount match
                invoice_amount = Decimal(str(invoice_data["amount"]))
                po_amount = po.amount
                
                amount_diff_percentage = abs(
                    (invoice_amount - po_amount) / po_amount * 100
                )
                
                # Consider matched if within 5% variance
                if amount_diff_percentage <= 5:
                    confidence = 1.0 - (amount_diff_percentage / 100)
                    return {
                        "matched": True,
                        "po_id": po.id,
                        "confidence": confidence,
                        "amount_variance": float(amount_diff_percentage)
                    }
                else:
                    return {
                        "matched": False,
                        "po_id": po.id,
                        "confidence": 0,
                        "amount_variance": float(amount_diff_percentage),
                        "reason": "Amount mismatch exceeds threshold"
                    }
                    
        except Exception as e:
            logger.error(f"PO matching error: {str(e)}")
            return {"matched": False, "error": str(e)}
    
    def _validate_vendor(self, vendor_id: str) -> Dict[str, Any]:
        """Validate vendor status and retrieve risk score"""
        try:
            with get_db_context() as db:
                vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
                
                if not vendor:
                    return {"valid": False, "message": "Vendor not found"}
                
                if not vendor.is_active:
                    return {"valid": False, "message": "Vendor is inactive"}
                
                if vendor.is_blacklisted:
                    return {
                        "valid": False, 
                        "message": "Vendor is blacklisted",
                        "risk_score": 1.0
                    }
                
                return {
                    "valid": True,
                    "risk_score": vendor.risk_score,
                    "performance_score": vendor.performance_score
                }
        except Exception as e:
            logger.error(f"Vendor validation error: {str(e)}")
            return {"valid": False, "message": str(e)}
    
    def _calculate_amounts(self, invoice_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate total amounts including tax"""
        amount = Decimal(str(invoice_data.get("amount", 0)))
        tax_amount = Decimal(str(invoice_data.get("tax_amount", 0)))
        
        # If tax not provided but tax rate is, calculate it
        if tax_amount == 0 and "tax_rate" in invoice_data:
            tax_rate = Decimal(str(invoice_data["tax_rate"]))
            tax_amount = amount * (tax_rate / 100)
        
        total_amount = amount + tax_amount
        
        invoice_data["amount"] = float(amount)
        invoice_data["tax_amount"] = float(tax_amount)
        invoice_data["total_amount"] = float(total_amount)
        
        return invoice_data
    
    def _assess_risk(self, invoice_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess risk level for the invoice"""
        risk_score = 0.0
        risk_factors = []
        
        # Factor 1: Amount threshold
        if invoice_data["total_amount"] > settings.HIGH_RISK_AMOUNT_THRESHOLD:
            risk_score += 0.3
            risk_factors.append("high_amount")
        
        # Factor 2: No PO match
        if not invoice_data.get("matched_po"):
            risk_score += 0.2
            risk_factors.append("no_po_match")
        
        # Factor 3: Vendor risk
        vendor_risk = invoice_data.get("vendor_risk_score", 0)
        risk_score += vendor_risk * 0.3
        if vendor_risk > 0.5:
            risk_factors.append("high_vendor_risk")
        
        # Factor 4: Low OCR confidence
        ocr_confidence = invoice_data.get("ocr_confidence", 1.0)
        if ocr_confidence < 0.8:
            risk_score += 0.1
            risk_factors.append("low_ocr_confidence")
        
        # Factor 5: Unusual patterns (add custom logic)
        # ...
        
        # Determine risk level
        if risk_score >= 0.7:
            risk_level = "high"
        elif risk_score >= 0.4:
            risk_level = "medium"
        else:
            risk_level = "low"
        
        return {
            "risk_score": min(risk_score, 1.0),
            "risk_level": risk_level,
            "factors": risk_factors
        }
    
    def _requires_approval(self, invoice_data: Dict[str, Any]) -> bool:
        """Determine if invoice requires manual approval"""
        # Auto-approve if low risk and below threshold
        if (invoice_data["risk_level"] == "low" and 
            invoice_data["total_amount"] <= self.auto_approve_amount and
            invoice_data.get("ocr_confidence", 0) >= self.confidence_threshold):
            return False
        
        return True
    
    def _determine_status(self, invoice_data: Dict[str, Any]) -> str:
        """Determine initial status of invoice"""
        if not self._requires_approval(invoice_data):
            return "auto_approved"
        return "pending_approval"
    
    def _determine_next_steps(self, invoice_data: Dict[str, Any]) -> List[str]:
        """Determine next steps for invoice processing"""
        steps = []
        
        if self._requires_approval(invoice_data):
            steps.append("route_for_approval")
        else:
            steps.append("auto_approve")
            steps.append("schedule_payment")
        
        if invoice_data["risk_level"] in ["medium", "high"]:
            steps.append("fraud_check")
        
        if not invoice_data.get("matched_po"):
            steps.append("notify_procurement")
        
        return steps