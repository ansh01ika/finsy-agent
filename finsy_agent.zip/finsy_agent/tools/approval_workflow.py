"""
Approval Workflow Tool
Manages multi-level approval workflows with escalation
"""
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from loguru import logger

from database import get_db_context
from models.database import Approval, Invoice, User, ApprovalStatus, UserRole
from utils.notifications import send_approval_notification, send_escalation_notification
from config import settings


class ApprovalWorkflowTool:
    """Tool for managing approval workflows"""
    
    def __init__(self):
        self.approval_timeout = settings.APPROVAL_TIMEOUT_HOURS
        self.escalation_timeout = settings.ESCALATION_TIMEOUT_HOURS
    
    def create_approval(
        self,
        invoice_id: str,
        approver_id: str,
        level: int = 1
    ) -> Dict[str, Any]:
        """
        Create approval request for invoice
        
        Args:
            invoice_id: Invoice ID
            approver_id: Approver user ID
            level: Approval level (1, 2, 3...)
            
        Returns:
            Approval creation result
        """
        try:
            with get_db_context() as db:
                # Verify invoice exists
                invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
                if not invoice:
                    return {"success": False, "error": "Invoice not found"}
                
                # Verify approver exists
                approver = db.query(User).filter(User.id == approver_id).first()
                if not approver:
                    return {"success": False, "error": "Approver not found"}
                
                # Create approval
                approval = Approval(
                    invoice_id=invoice_id,
                    approver_id=approver_id,
                    approval_level=level,
                    timeout_at=datetime.utcnow() + timedelta(hours=self.approval_timeout)
                )
                
                db.add(approval)
                db.commit()
                db.refresh(approval)
                
                # Send notification
                send_approval_notification(approver.email, invoice, approval)
                
                logger.info(f"Approval created: {approval.id} for invoice {invoice_id}")
                
                return {
                    "success": True,
                    "approval_id": approval.id,
                    "approver": approver.username,
                    "level": level,
                    "timeout_at": approval.timeout_at.isoformat()
                }
        
        except Exception as e:
            logger.error(f"Approval creation error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def process_approval_decision(
        self,
        approval_id: str,
        decision: str,
        comments: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process approval decision
        
        Args:
            approval_id: Approval ID
            decision: approve or reject
            comments: Optional comments
            
        Returns:
            Processing result
        """
        try:
            with get_db_context() as db:
                approval = db.query(Approval).filter(Approval.id == approval_id).first()
                if not approval:
                    return {"success": False, "error": "Approval not found"}
                
                if approval.status != ApprovalStatus.PENDING:
                    return {
                        "success": False,
                        "error": f"Approval already {approval.status.value}"
                    }
                
                # Update approval
                if decision.lower() == "approve":
                    approval.status = ApprovalStatus.APPROVED
                elif decision.lower() == "reject":
                    approval.status = ApprovalStatus.REJECTED
                else:
                    return {"success": False, "error": "Invalid decision"}
                
                approval.responded_at = datetime.utcnow()
                approval.comments = comments
                
                # Update invoice
                invoice = db.query(Invoice).filter(Invoice.id == approval.invoice_id).first()
                if invoice:
                    if approval.status == ApprovalStatus.APPROVED:
                        # Check if more approvals needed
                        if self._requires_additional_approval(invoice):
                            next_approver = self._get_next_approver(invoice, approval.approval_level)
                            if next_approver:
                                self.create_approval(
                                    invoice.id,
                                    next_approver.id,
                                    approval.approval_level + 1
                                )
                        else:
                            invoice.status = "approved"
                    else:
                        invoice.status = "rejected"
                
                db.commit()
                
                return {
                    "success": True,
                    "approval_id": approval_id,
                    "decision": approval.status.value,
                    "invoice_status": invoice.status if invoice else None
                }
        
        except Exception as e:
            logger.error(f"Approval processing error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def escalate_approval(
        self,
        approval_id: str,
        escalate_to: str,
        reason: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Escalate approval to higher authority
        
        Args:
            approval_id: Current approval ID
            escalate_to: User ID to escalate to
            reason: Escalation reason
            
        Returns:
            Escalation result
        """
        try:
            with get_db_context() as db:
                approval = db.query(Approval).filter(Approval.id == approval_id).first()
                if not approval:
                    return {"success": False, "error": "Approval not found"}
                
                escalation_user = db.query(User).filter(User.id == escalate_to).first()
                if not escalation_user:
                    return {"success": False, "error": "Escalation user not found"}
                
                # Update current approval
                approval.status = ApprovalStatus.ESCALATED
                approval.is_escalated = True
                approval.escalated_to = escalate_to
                
                # Create new approval
                new_approval = Approval(
                    invoice_id=approval.invoice_id,
                    approver_id=escalate_to,
                    approval_level=approval.approval_level + 1,
                    comments=f"Escalated: {reason}" if reason else "Escalated",
                    timeout_at=datetime.utcnow() + timedelta(hours=self.escalation_timeout)
                )
                
                db.add(new_approval)
                db.commit()
                db.refresh(new_approval)
                
                # Send notification
                send_escalation_notification(escalation_user.email, approval, new_approval)
                
                return {
                    "success": True,
                    "new_approval_id": new_approval.id,
                    "escalated_to": escalation_user.username
                }
        
        except Exception as e:
            logger.error(f"Escalation error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def check_timeouts(self) -> List[Dict[str, Any]]:
        """
        Check for timed out approvals and auto-escalate
        
        Returns:
            List of handled timeouts
        """
        try:
            with get_db_context() as db:
                now = datetime.utcnow()
                
                # Find timed out approvals
                timed_out = db.query(Approval).filter(
                    Approval.status == ApprovalStatus.PENDING,
                    Approval.timeout_at <= now
                ).all()
                
                results = []
                for approval in timed_out:
                    # Auto-escalate
                    escalation_user = self._get_escalation_user(approval)
                    if escalation_user:
                        result = self.escalate_approval(
                            approval.id,
                            escalation_user.id,
                            "Automatic escalation due to timeout"
                        )
                        results.append(result)
                
                return results
        
        except Exception as e:
            logger.error(f"Timeout check error: {str(e)}")
            return []
    
    def _requires_additional_approval(self, invoice) -> bool:
        """Check if invoice requires additional approval levels"""
        # If amount is very high, require multiple approvals
        if float(invoice.total_amount) > 50000:
            # Check how many approvals already exist
            with get_db_context() as db:
                approval_count = db.query(Approval).filter(
                    Approval.invoice_id == invoice.id,
                    Approval.status == ApprovalStatus.APPROVED
                ).count()
                
                # Require 2 approvals for high amounts
                return approval_count < 2
        
        return False
    
    def _get_next_approver(self, invoice, current_level: int):
        """Get next approver in hierarchy"""
        with get_db_context() as db:
            # Get users with higher approval authority
            next_approver = db.query(User).filter(
                User.role.in_([UserRole.FINANCE_MANAGER, UserRole.ADMIN]),
                User.is_active == True
            ).first()
            
            return next_approver
    
    def _get_escalation_user(self, approval):
        """Get user for escalation"""
        with get_db_context() as db:
            # Get manager or admin
            escalation_user = db.query(User).filter(
                User.role.in_([UserRole.FINANCE_MANAGER, UserRole.ADMIN]),
                User.is_active == True
            ).first()
            
            return escalation_user