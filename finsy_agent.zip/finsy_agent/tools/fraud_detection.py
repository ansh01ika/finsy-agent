"""
Fraud Detection Tool
Real-time fraud detection and risk scoring
"""
from typing import Dict, Any, List
from datetime import datetime, timedelta
from decimal import Decimal
from loguru import logger
import numpy as np

from database import get_db_context
from models.database import Invoice, Transaction, FraudAlert, Vendor
from ml.models import fraud_detection_model
from config import settings


class FraudDetectionTool:
    """Tool for detecting fraudulent activities"""
    
    def __init__(self):
        self.threshold = settings.FRAUD_SCORE_THRESHOLD
        self.model = fraud_detection_model
    
    def detect_fraud(self, entity_type: str, entity_id: str) -> Dict[str, Any]:
        """
        Detect potential fraud in entity
        
        Args:
            entity_type: Type (invoice, transaction, vendor)
            entity_id: Entity ID
            
        Returns:
            Fraud detection results
        """
        try:
            if entity_type == "invoice":
                return self._detect_invoice_fraud(entity_id)
            elif entity_type == "transaction":
                return self._detect_transaction_fraud(entity_id)
            elif entity_type == "vendor":
                return self._detect_vendor_fraud(entity_id)
            else:
                return {"error": "Invalid entity type"}
        
        except Exception as e:
            logger.error(f"Fraud detection error: {str(e)}")
            return {"error": str(e), "success": False}
    
    def _detect_invoice_fraud(self, invoice_id: str) -> Dict[str, Any]:
        """Detect fraud in invoice"""
        with get_db_context() as db:
            invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
            
            if not invoice:
                return {"error": "Invoice not found"}
            
            fraud_indicators = []
            fraud_score = 0.0
            
            # Check 1: Duplicate detection
            duplicates = self._check_duplicates(db, invoice)
            if duplicates["found"]:
                fraud_score += 0.4
                fraud_indicators.append({
                    "type": "duplicate_invoice",
                    "severity": "high",
                    "details": duplicates
                })
            
            # Check 2: Amount anomaly
            amount_check = self._check_amount_anomaly(db, invoice)
            if amount_check["is_anomaly"]:
                fraud_score += 0.3
                fraud_indicators.append({
                    "type": "amount_anomaly",
                    "severity": "medium",
                    "details": amount_check
                })
            
            # Check 3: Vendor risk
            vendor = db.query(Vendor).filter(Vendor.id == invoice.vendor_id).first()
            if vendor and vendor.risk_score > 0.7:
                fraud_score += 0.2
                fraud_indicators.append({
                    "type": "high_risk_vendor",
                    "severity": "medium",
                    "vendor_risk_score": vendor.risk_score
                })
            
            # Check 4: Pattern matching using ML
            if self.model:
                ml_score = self._ml_fraud_detection(invoice)
                fraud_score += ml_score * 0.3
                if ml_score > 0.7:
                    fraud_indicators.append({
                        "type": "ml_pattern_detection",
                        "severity": "high",
                        "ml_score": ml_score
                    })
            
            # Normalize score
            fraud_score = min(fraud_score, 1.0)
            
            # Create alert if above threshold
            if fraud_score >= self.threshold:
                alert = FraudAlert(
                    entity_type="invoice",
                    entity_id=invoice_id,
                    alert_type="automated_detection",
                    severity="high" if fraud_score > 0.8 else "medium",
                    fraud_score=fraud_score,
                    description=f"Fraud detected: score {fraud_score:.2f}",
                    evidence={"indicators": fraud_indicators},
                    detection_method="automated_ml"
                )
                db.add(alert)
                db.commit()
            
            return {
                "success": True,
                "entity_type": "invoice",
                "entity_id": invoice_id,
                "fraud_score": fraud_score,
                "risk_level": "high" if fraud_score > 0.8 else "medium" if fraud_score > 0.5 else "low",
                "indicators": fraud_indicators,
                "requires_investigation": fraud_score >= self.threshold
            }
    
    def _check_duplicates(self, db, invoice) -> Dict[str, Any]:
        """Check for duplicate invoices"""
        window_start = datetime.utcnow() - timedelta(days=settings.DUPLICATE_CHECK_WINDOW_DAYS)
        
        similar = db.query(Invoice).filter(
            Invoice.vendor_id == invoice.vendor_id,
            Invoice.id != invoice.id,
            Invoice.created_at >= window_start,
            Invoice.total_amount == invoice.total_amount
        ).all()
        
        if similar:
            return {
                "found": True,
                "count": len(similar),
                "similar_invoices": [s.id for s in similar]
            }
        
        return {"found": False}
    
    def _check_amount_anomaly(self, db, invoice) -> Dict[str, Any]:
        """Check if amount is anomalous for vendor"""
        # Get vendor's transaction history
        recent_invoices = db.query(Invoice).filter(
            Invoice.vendor_id == invoice.vendor_id,
            Invoice.id != invoice.id,
            Invoice.status != "rejected"
        ).order_by(Invoice.invoice_date.desc()).limit(20).all()
        
        if len(recent_invoices) < 5:
            return {"is_anomaly": False, "reason": "insufficient_history"}
        
        amounts = [float(inv.total_amount) for inv in recent_invoices]
        mean_amount = np.mean(amounts)
        std_amount = np.std(amounts)
        
        current_amount = float(invoice.total_amount)
        
        # Check if current amount is more than 3 standard deviations
        if std_amount > 0:
            z_score = abs((current_amount - mean_amount) / std_amount)
            
            if z_score > 3:
                return {
                    "is_anomaly": True,
                    "z_score": z_score,
                    "mean_amount": mean_amount,
                    "std_amount": std_amount
                }
        
        return {"is_anomaly": False}
    
    def _ml_fraud_detection(self, invoice) -> float:
        """Use ML model for fraud detection"""
        try:
            if not self.model:
                return 0.0
            
            # Prepare features
            features = self._extract_features(invoice)
            
            # Get prediction
            fraud_probability = self.model.predict_proba([features])[0][1]
            
            return fraud_probability
        except Exception as e:
            logger.error(f"ML fraud detection error: {str(e)}")
            return 0.0
    
    def _extract_features(self, invoice) -> List[float]:
        """Extract features for ML model"""
        # Implement feature extraction logic
        return [
            float(invoice.total_amount),
            1.0 if invoice.matched_po else 0.0,
            invoice.confidence_score,
            # Add more features
        ]
    
    def _detect_transaction_fraud(self, transaction_id: str) -> Dict[str, Any]:
        """Detect fraud in transaction"""
        # Similar implementation for transactions
        return {"success": True, "fraud_score": 0.0}
    
    def _detect_vendor_fraud(self, vendor_id: str) -> Dict[str, Any]:
        """Detect fraud patterns in vendor"""
        # Similar implementation for vendors
        return {"success": True, "fraud_score": 0.0}