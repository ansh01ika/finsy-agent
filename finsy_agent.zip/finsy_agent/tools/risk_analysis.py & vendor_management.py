"""
Risk Analysis and Vendor Management Tools
"""
from typing import Dict, Any
from loguru import logger
from database import get_db_context
from models.database import Vendor, Invoice
from sqlalchemy import func


class RiskAnalysisTool:
    """Tool for analyzing financial risks"""
    
    def analyze_risk(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze risk for transaction or project
        
        Args:
            transaction_data: Transaction data to analyze
            
        Returns:
            Risk analysis results
        """
        try:
            risk_score = 0.0
            risk_factors = []
            
            # Analyze amount
            amount = transaction_data.get("amount", 0)
            if amount > 50000:
                risk_score += 0.3
                risk_factors.append("high_amount")
            
            # Analyze vendor
            vendor_id = transaction_data.get("vendor_id")
            if vendor_id:
                with get_db_context() as db:
                    vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
                    if vendor:
                        risk_score += vendor.risk_score * 0.4
                        if vendor.risk_score > 0.5:
                            risk_factors.append("high_vendor_risk")
            
            # Determine risk level
            if risk_score >= 0.7:
                risk_level = "high"
            elif risk_score >= 0.4:
                risk_level = "medium"
            else:
                risk_level = "low"
            
            return {
                "success": True,
                "risk_score": min(risk_score, 1.0),
                "risk_level": risk_level,
                "risk_factors": risk_factors,
                "recommendations": self._get_risk_recommendations(risk_level)
            }
        
        except Exception as e:
            logger.error(f"Risk analysis error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _get_risk_recommendations(self, risk_level: str) -> list:
        """Get recommendations based on risk level"""
        if risk_level == "high":
            return [
                "Require multiple approvals",
                "Enhanced verification required",
                "Consider fraud investigation"
            ]
        elif risk_level == "medium":
            return [
                "Manager approval required",
                "Additional documentation needed"
            ]
        else:
            return ["Standard processing"]


class VendorManagementTool:
    """Tool for vendor evaluation and management"""
    
    def evaluate_vendor(self, vendor_id: str) -> Dict[str, Any]:
        """
        Evaluate vendor performance and reliability
        
        Args:
            vendor_id: Vendor ID
            
        Returns:
            Vendor evaluation results
        """
        try:
            with get_db_context() as db:
                vendor = db.query(Vendor).filter(Vendor.id == vendor_id).first()
                
                if not vendor:
                    return {"success": False, "error": "Vendor not found"}
                
                # Get invoice statistics
                invoice_count = db.query(func.count(Invoice.id)).filter(
                    Invoice.vendor_id == vendor_id
                ).scalar()
                
                avg_amount = db.query(func.avg(Invoice.total_amount)).filter(
                    Invoice.vendor_id == vendor_id
                ).scalar() or 0
                
                # Count late payments
                late_payments = db.query(func.count(Invoice.id)).filter(
                    Invoice.vendor_id == vendor_id,
                    Invoice.payment_date > Invoice.due_date
                ).scalar()
                
                # Calculate performance metrics
                on_time_rate = 1.0 - (late_payments / invoice_count) if invoice_count > 0 else 1.0
                
                # Update vendor performance score
                vendor.performance_score = on_time_rate
                db.commit()
                
                return {
                    "success": True,
                    "vendor_id": vendor_id,
                    "vendor_name": vendor.name,
                    "risk_score": vendor.risk_score,
                    "performance_score": on_time_rate,
                    "total_invoices": invoice_count,
                    "average_invoice_amount": float(avg_amount),
                    "late_payment_count": late_payments,
                    "on_time_payment_rate": on_time_rate * 100,
                    "is_active": vendor.is_active,
                    "is_blacklisted": vendor.is_blacklisted,
                    "recommendation": self._get_vendor_recommendation(vendor.risk_score, on_time_rate)
                }
        
        except Exception as e:
            logger.error(f"Vendor evaluation error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def compare_vendors(self, vendor_ids: list) -> Dict[str, Any]:
        """
        Compare multiple vendors
        
        Args:
            vendor_ids: List of vendor IDs to compare
            
        Returns:
            Comparison results
        """
        try:
            results = []
            for vendor_id in vendor_ids:
                eval_result = self.evaluate_vendor(vendor_id)
                if eval_result.get("success"):
                    results.append(eval_result)
            
            # Rank vendors
            ranked = sorted(
                results,
                key=lambda x: (x["performance_score"], -x["risk_score"]),
                reverse=True
            )
            
            return {
                "success": True,
                "comparison": ranked,
                "best_vendor": ranked[0] if ranked else None
            }
        
        except Exception as e:
            logger.error(f"Vendor comparison error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _get_vendor_recommendation(self, risk_score: float, performance_score: float) -> str:
        """Get recommendation for vendor"""
        if risk_score > 0.7 or performance_score < 0.5:
            return "Consider reviewing this vendor relationship"
        elif risk_score > 0.5 or performance_score < 0.7:
            return "Monitor vendor performance closely"
        else:
            return "Vendor performs well, continue relationship"