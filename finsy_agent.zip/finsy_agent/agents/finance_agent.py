"""
Main Finance Agentic AI Implementation (Finsy)
"""
from typing import List, Dict, Any, Optional
from phi.agent import Agent
from phi.model.openai import OpenAIChat
from phi.tools import tool
from langchain.memory import ConversationBufferMemory
from loguru import logger
from datetime import datetime
import json

from config import settings
from tools.invoice_processing import InvoiceProcessingTool
from tools.fraud_detection import FraudDetectionTool
from tools.approval_workflow import ApprovalWorkflowTool
from tools.reporting import ReportingTool
from tools.risk_analysis import RiskAnalysisTool
from tools.vendor_management import VendorManagementTool


class FinsyAgent:
    """
    Main Finance Agentic AI - Finsy
    Handles financial operations, automation, and intelligent decision-making
    """
    
    def __init__(self):
        self.invoice_tool = InvoiceProcessingTool()
        self.fraud_tool = FraudDetectionTool()
        self.approval_tool = ApprovalWorkflowTool()
        self.reporting_tool = ReportingTool()
        self.risk_tool = RiskAnalysisTool()
        self.vendor_tool = VendorManagementTool()
        
        # Initialize memory for conversation
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
        
        # Initialize the agent
        self.agent = self._create_agent()
        
        logger.info("Finsy Agent initialized successfully")
    
    def _create_agent(self) -> Agent:
        """Create the main agent with tools"""
        
        system_prompt = """
        You are Finsy, an intelligent Finance Agentic AI assistant designed to help with:
        - Invoice processing and validation
        - Fraud detection and risk analysis
        - Approval workflow management
        - Financial reporting and analytics
        - Vendor evaluation and management
        - Compliance monitoring
        
        You have access to multiple tools and can execute complex financial workflows.
        Always prioritize accuracy, security, and compliance in your responses.
        Provide clear explanations for your decisions and flag any suspicious activities.
        
        When processing financial data:
        1. Validate all inputs thoroughly
        2. Check for fraud indicators
        3. Apply appropriate risk scoring
        4. Follow approval workflows
        5. Maintain audit trails
        6. Ensure regulatory compliance
        """
        
        agent = Agent(
            name="Finsy",
            model=OpenAIChat(
                id=settings.LLM_MODEL,
                api_key=settings.OPENAI_API_KEY,
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS
            ),
            instructions=system_prompt,
            tools=[
                self.process_invoice_tool,
                self.detect_fraud_tool,
                self.create_approval_tool,
                self.generate_report_tool,
                self.analyze_risk_tool,
                self.evaluate_vendor_tool,
                self.search_transactions_tool,
                self.get_budget_status_tool
            ],
            show_tool_calls=settings.DEBUG,
            markdown=True
        )
        
        return agent
    
    @tool
    def process_invoice_tool(self, invoice_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process and validate an invoice
        
        Args:
            invoice_data: Dictionary containing invoice information
            
        Returns:
            Processing result with validation status
        """
        try:
            result = self.invoice_tool.process_invoice(invoice_data)
            logger.info(f"Invoice processed: {invoice_data.get('invoice_number')}")
            return result
        except Exception as e:
            logger.error(f"Invoice processing error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def detect_fraud_tool(self, entity_type: str, entity_id: str) -> Dict[str, Any]:
        """
        Detect potential fraud in transactions or invoices
        
        Args:
            entity_type: Type of entity (invoice, transaction, vendor)
            entity_id: ID of the entity to check
            
        Returns:
            Fraud detection results with risk score
        """
        try:
            result = self.fraud_tool.detect_fraud(entity_type, entity_id)
            if result.get("fraud_score", 0) > settings.FRAUD_SCORE_THRESHOLD:
                logger.warning(f"High fraud risk detected: {entity_type} {entity_id}")
            return result
        except Exception as e:
            logger.error(f"Fraud detection error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def create_approval_tool(self, invoice_id: str, approver_id: str) -> Dict[str, Any]:
        """
        Create approval workflow for an invoice
        
        Args:
            invoice_id: Invoice ID requiring approval
            approver_id: ID of the approver
            
        Returns:
            Approval creation status
        """
        try:
            result = self.approval_tool.create_approval(invoice_id, approver_id)
            logger.info(f"Approval created for invoice: {invoice_id}")
            return result
        except Exception as e:
            logger.error(f"Approval creation error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def generate_report_tool(
        self, 
        report_type: str, 
        start_date: str, 
        end_date: str
    ) -> Dict[str, Any]:
        """
        Generate financial reports
        
        Args:
            report_type: Type of report (P&L, balance_sheet, cash_flow)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            Generated report data
        """
        try:
            result = self.reporting_tool.generate_report(
                report_type, start_date, end_date
            )
            logger.info(f"Report generated: {report_type}")
            return result
        except Exception as e:
            logger.error(f"Report generation error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def analyze_risk_tool(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze risk for transactions or projects
        
        Args:
            transaction_data: Transaction data to analyze
            
        Returns:
            Risk analysis results
        """
        try:
            result = self.risk_tool.analyze_risk(transaction_data)
            return result
        except Exception as e:
            logger.error(f"Risk analysis error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def evaluate_vendor_tool(self, vendor_id: str) -> Dict[str, Any]:
        """
        Evaluate vendor performance and reliability
        
        Args:
            vendor_id: Vendor ID to evaluate
            
        Returns:
            Vendor evaluation results
        """
        try:
            result = self.vendor_tool.evaluate_vendor(vendor_id)
            logger.info(f"Vendor evaluated: {vendor_id}")
            return result
        except Exception as e:
            logger.error(f"Vendor evaluation error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def search_transactions_tool(
        self, 
        filters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Search and retrieve transactions based on filters
        
        Args:
            filters: Search filters (date_range, amount, vendor, status)
            
        Returns:
            List of matching transactions
        """
        try:
            from database import get_db_context
            from models.database import Transaction
            from sqlalchemy import and_
            
            with get_db_context() as db:
                query = db.query(Transaction)
                
                # Apply filters
                if "start_date" in filters:
                    query = query.filter(
                        Transaction.transaction_date >= filters["start_date"]
                    )
                if "end_date" in filters:
                    query = query.filter(
                        Transaction.transaction_date <= filters["end_date"]
                    )
                if "min_amount" in filters:
                    query = query.filter(Transaction.amount >= filters["min_amount"])
                if "max_amount" in filters:
                    query = query.filter(Transaction.amount <= filters["max_amount"])
                if "vendor_id" in filters:
                    query = query.filter(Transaction.vendor_id == filters["vendor_id"])
                if "status" in filters:
                    query = query.filter(Transaction.status == filters["status"])
                
                transactions = query.limit(100).all()
                
                return {
                    "success": True,
                    "count": len(transactions),
                    "transactions": [
                        {
                            "id": t.id,
                            "transaction_id": t.transaction_id,
                            "amount": float(t.amount),
                            "date": t.transaction_date.isoformat(),
                            "status": t.status.value
                        }
                        for t in transactions
                    ]
                }
        except Exception as e:
            logger.error(f"Transaction search error: {str(e)}")
            return {"error": str(e), "success": False}
    
    @tool
    def get_budget_status_tool(self, department: str, fiscal_year: int) -> Dict[str, Any]:
        """
        Get budget status for a department
        
        Args:
            department: Department name
            fiscal_year: Fiscal year
            
        Returns:
            Budget status and utilization
        """
        try:
            from database import get_db_context
            from models.database import Budget
            
            with get_db_context() as db:
                budgets = db.query(Budget).filter(
                    Budget.department == department,
                    Budget.fiscal_year == fiscal_year
                ).all()
                
                total_allocated = sum(float(b.allocated_amount) for b in budgets)
                total_spent = sum(float(b.spent_amount) for b in budgets)
                
                return {
                    "success": True,
                    "department": department,
                    "fiscal_year": fiscal_year,
                    "total_allocated": total_allocated,
                    "total_spent": total_spent,
                    "remaining": total_allocated - total_spent,
                    "utilization_percentage": (total_spent / total_allocated * 100) if total_allocated > 0 else 0,
                    "budgets": [
                        {
                            "category": b.category,
                            "allocated": float(b.allocated_amount),
                            "spent": float(b.spent_amount),
                            "remaining": float(b.remaining_amount) if b.remaining_amount else 0
                        }
                        for b in budgets
                    ]
                }
        except Exception as e:
            logger.error(f"Budget status error: {str(e)}")
            return {"error": str(e), "success": False}
    
    async def process_query(self, query: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Process user query and return response
        
        Args:
            query: User query in natural language
            context: Additional context for the query
            
        Returns:
            Agent response with results
        """
        try:
            # Add context to the query if provided
            if context:
                query = f"Context: {json.dumps(context)}\n\nQuery: {query}"
            
            # Get response from agent
            response = self.agent.run(query)
            
            # Store in memory
            self.memory.save_context(
                {"input": query},
                {"output": response.content}
            )
            
            return {
                "success": True,
                "response": response.content,
                "timestamp": datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Query processing error: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def clear_memory(self):
        """Clear conversation memory"""
        self.memory.clear()
        logger.info("Agent memory cleared")


# Global agent instance
finsy_agent = FinsyAgent()