"""
Scheduled Background Tasks
"""
from celery_app import celery
from loguru import logger
from datetime import datetime, timedelta
from database import get_db_context
from models.database import Approval, AuditLog, Vendor, Invoice
from tools.approval_workflow import ApprovalWorkflowTool
from agents.finance_agent import finsy_agent


@celery.task(name='tasks.scheduled_tasks.check_approval_timeouts')
def check_approval_timeouts():
    """Check for timed out approvals and escalate"""
    try:
        logger.info("Checking approval timeouts...")
        
        approval_tool = ApprovalWorkflowTool()
        results = approval_tool.check_timeouts()
        
        logger.info(f"Processed {len(results)} timed out approvals")
        
        return {
            "success": True,
            "processed": len(results),
            "results": results
        }
    
    except Exception as e:
        logger.error(f"Approval timeout check error: {str(e)}")
        return {"success": False, "error": str(e)}


@celery.task(name='tasks.scheduled_tasks.generate_daily_reports')
def generate_daily_reports():
    """Generate daily financial reports"""
    try:
        logger.info("Generating daily reports...")
        
        from tools.reporting import ReportingTool
        
        reporting_tool = ReportingTool()
        today = datetime.now()
        yesterday = today - timedelta(days=1)
        
        # Generate P&L report
        pl_report = reporting_tool.generate_report(
            "profit_loss",
            yesterday.strftime("%Y-%m-%d"),
            today.strftime("%Y-%m-%d")
        )
        
        # Generate cash flow report
        cf_report = reporting_tool.generate_report(
            "cash_flow",
            yesterday.strftime("%Y-%m-%d"),
            today.strftime("%Y-%m-%d")
        )
        
        logger.info("Daily reports generated successfully")
        
        return {
            "success": True,
            "reports": ["profit_loss", "cash_flow"]
        }
    
    except Exception as e:
        logger.error(f"Daily report generation error: {str(e)}")
        return {"success": False, "error": str(e)}


@celery.task(name='tasks.scheduled_tasks.check_fraud_patterns')
def check_fraud_patterns():
    """Check for fraud patterns across all invoices"""
    try:
        logger.info("Checking fraud patterns...")
        
        with get_db_context() as db:
            # Get recent invoices
            recent_date = datetime.utcnow() - timedelta(days=7)
            recent_invoices = db.query(Invoice).filter(
                Invoice.created_at >= recent_date,
                Invoice.risk_level.in_(["medium", "high"])
            ).all()
            
            fraud_checks = 0
            alerts_created = 0
            
            for invoice in recent_invoices:
                result = finsy_agent.fraud_tool.detect_fraud("invoice", invoice.id)
                fraud_checks += 1
                
                if result.get("requires_investigation"):
                    alerts_created += 1
            
            logger.info(f"Fraud pattern check complete: {fraud_checks} checked, {alerts_created} alerts")
            
            return {
                "success": True,
                "checked": fraud_checks,
                "alerts": alerts_created
            }
    
    except Exception as e:
        logger.error(f"Fraud pattern check error: {str(e)}")
        return {"success": False, "error": str(e)}


@celery.task(name='tasks.scheduled_tasks.update_vendor_scores')
def update_vendor_scores():
    """Update vendor risk and performance scores"""
    try:
        logger.info("Updating vendor scores...")
        
        with get_db_context() as db:
            vendors = db.query(Vendor).filter(Vendor.is_active == True).all()
            
            updated = 0
            for vendor in vendors:
                result = finsy_agent.vendor_tool.evaluate_vendor(vendor.id)
                if result.get("success"):
                    updated += 1
            
            logger.info(f"Updated scores for {updated} vendors")
            
            return {
                "success": True,
                "updated": updated
            }
    
    except Exception as e:
        logger.error(f"Vendor score update error: {str(e)}")
        return {"success": False, "error": str(e)}


@celery.task(name='tasks.scheduled_tasks.cleanup_old_logs')
def cleanup_old_logs():
    """Clean up old audit logs"""
    try:
        logger.info("Cleaning up old logs...")
        
        from config import settings
        
        with get_db_context() as db:
            # Calculate cutoff date
            cutoff_date = datetime.utcnow() - timedelta(days=settings.AUDIT_LOG_RETENTION_DAYS)
            
            # Delete old logs
            deleted = db.query(AuditLog).filter(
                AuditLog.timestamp < cutoff_date
            ).delete()
            
            db.commit()
            
            logger.info(f"Deleted {deleted} old audit logs")
            
            return {
                "success": True,
                "deleted": deleted
            }
    
    except Exception as e:
        logger.error(f"Log cleanup error: {str(e)}")
        return {"success": False, "error": str(e)}


@celery.task(name='tasks.scheduled_tasks.check_reconciliation')
def check_reconciliation():
    """Check for unreconciled transactions"""
    try:
        logger.info("Checking reconciliation status...")
        
        from models.database import Transaction
        
        with get_db_context() as db:
            # Get unreconciled transactions
            unreconciled = db.query(Transaction).filter(
                Transaction.is_reconciled == False,
                Transaction.status == "completed"
            ).all()
            
            # Send notifications for old unreconciled transactions
            old_date = datetime.utcnow() - timedelta(days=30)
            old_unreconciled = [t for t in unreconciled if t.transaction_date < old_date]
            
            logger.info(f"Found {len(unreconciled)} unreconciled transactions, {len(old_unreconciled)} overdue")
            
            return {
                "success": True,
                "unreconciled": len(unreconciled),
                "overdue": len(old_unreconciled)
            }
    
    except Exception as e:
        logger.error(f"Reconciliation check error: {str(e)}")
        return {"success": False, "error": str(e)}


@celery.task(name='tasks.scheduled_tasks.send_daily_summary')
def send_daily_summary():
    """Send daily summary email to finance team"""
    try:
        logger.info("Sending daily summary...")
        
        from utils.notifications import send_email
        from sqlalchemy import func
        
        with get_db_context() as db:
            # Get statistics
            pending_approvals = db.query(func.count(Approval.id)).filter(
                Approval.status == "pending"
            ).scalar()
            
            open_fraud_alerts = db.query(func.count(FraudAlert.id)).filter(
                FraudAlert.status == "open"
            ).scalar()
            
            today_invoices = db.query(func.count(Invoice.id)).filter(
                Invoice.created_at >= datetime.utcnow().date()
            ).scalar()
        
        # Send email
        # await send_email(...)
        
        logger.info("Daily summary sent")
        
        return {"success": True}
    
    except Exception as e:
        logger.error(f"Daily summary error: {str(e)}")
        return {"success": False, "error": str(e)}