"""
Test Invoice Processing
"""
import pytest
from datetime import datetime
from decimal import Decimal
from unittest.mock import Mock, patch

from tools.invoice_processing import InvoiceProcessingTool
from models.database import Invoice, Vendor, PurchaseOrder


@pytest.fixture
def invoice_tool():
    """Create InvoiceProcessingTool instance"""
    return InvoiceProcessingTool()


@pytest.fixture
def sample_invoice_data():
    """Sample invoice data for testing"""
    return {
        "invoice_number": "INV-TEST-001",
        "vendor_id": "vendor-123",
        "invoice_date": "2025-01-15",
        "due_date": "2025-02-15",
        "amount": 5000.00,
        "tax_amount": 500.00,
        "currency": "USD",
        "po_number": "PO-2025-100",
        "line_items": [
            {"description": "Service A", "quantity": 1, "unit_price": 5000.00}
        ]
    }


@pytest.fixture
def sample_vendor():
    """Create sample vendor"""
    return Vendor(
        id="vendor-123",
        vendor_code="VEN-001",
        name="Test Vendor Inc",
        email="vendor@test.com",
        is_active=True,
        is_blacklisted=False,
        risk_score=0.2,
        performance_score=0.9
    )


@pytest.fixture
def sample_po():
    """Create sample purchase order"""
    return PurchaseOrder(
        id="po-123",
        po_number="PO-2025-100",
        vendor_id="vendor-123",
        po_date=datetime(2025, 1, 1),
        amount=Decimal("5000.00"),
        currency="USD",
        status="open"
    )


class TestInvoiceProcessing:
    """Test invoice processing functionality"""
    
    @pytest.mark.unit
    def test_calculate_amounts(self, invoice_tool, sample_invoice_data):
        """Test amount calculation"""
        result = invoice_tool._calculate_amounts(sample_invoice_data)
        
        assert result["amount"] == 5000.00
        assert result["tax_amount"] == 500.00
        assert result["total_amount"] == 5500.00
    
    @pytest.mark.unit
    def test_calculate_amounts_with_tax_rate(self, invoice_tool):
        """Test amount calculation with tax rate"""
        data = {
            "amount": 1000.00,
            "tax_rate": 10.0
        }
        
        result = invoice_tool._calculate_amounts(data)
        
        assert result["amount"] == 1000.00
        assert result["tax_amount"] == 100.00
        assert result["total_amount"] == 1100.00
    
    @pytest.mark.unit
    def test_assess_risk_low(self, invoice_tool):
        """Test low risk assessment"""
        invoice_data = {
            "total_amount": 500.00,
            "matched_po": True,
            "vendor_risk_score": 0.1,
            "ocr_confidence": 0.95
        }
        
        result = invoice_tool._assess_risk(invoice_data)
        
        assert result["risk_level"] == "low"
        assert result["risk_score"] < 0.4
        assert len(result["factors"]) == 0
    
    @pytest.mark.unit
    def test_assess_risk_high(self, invoice_tool):
        """Test high risk assessment"""
        invoice_data = {
            "total_amount": 100000.00,  # High amount
            "matched_po": False,  # No PO match
            "vendor_risk_score": 0.8,  # High vendor risk
            "ocr_confidence": 0.6  # Low confidence
        }
        
        result = invoice_tool._assess_risk(invoice_data)
        
        assert result["risk_level"] == "high"
        assert result["risk_score"] >= 0.7
        assert "high_amount" in result["factors"]
        assert "no_po_match" in result["factors"]
    
    @pytest.mark.unit
    def test_requires_approval_low_risk(self, invoice_tool):
        """Test approval requirement for low risk invoice"""
        invoice_data = {
            "risk_level": "low",
            "total_amount": 500.00,
            "ocr_confidence": 0.95
        }
        
        result = invoice_tool._requires_approval(invoice_data)
        
        assert result is False  # Should auto-approve
    
    @pytest.mark.unit
    def test_requires_approval_high_risk(self, invoice_tool):
        """Test approval requirement for high risk invoice"""
        invoice_data = {
            "risk_level": "high",
            "total_amount": 50000.00,
            "ocr_confidence": 0.95
        }
        
        result = invoice_tool._requires_approval(invoice_data)
        
        assert result is True  # Should require approval
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_check_duplicate_invoice(self, mock_db, invoice_tool):
        """Test duplicate invoice detection"""
        # Mock database query
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        
        # No duplicate found
        mock_session.query.return_value.filter.return_value.first.return_value = None
        
        result = invoice_tool._check_duplicate_invoice("INV-001", "vendor-123")
        
        assert result["is_duplicate"] is False
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_check_duplicate_invoice_found(self, mock_db, invoice_tool):
        """Test duplicate invoice detection when duplicate exists"""
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        
        # Duplicate found
        existing_invoice = Mock()
        existing_invoice.id = "existing-id"
        existing_invoice.status.value = "approved"
        mock_session.query.return_value.filter.return_value.first.return_value = existing_invoice
        
        result = invoice_tool._check_duplicate_invoice("INV-001", "vendor-123")
        
        assert result["is_duplicate"] is True
        assert result["existing_id"] == "existing-id"
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_validate_vendor_success(self, mock_db, invoice_tool, sample_vendor):
        """Test successful vendor validation"""
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        mock_session.query.return_value.filter.return_value.first.return_value = sample_vendor
        
        result = invoice_tool._validate_vendor("vendor-123")
        
        assert result["valid"] is True
        assert result["risk_score"] == 0.2
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_validate_vendor_not_found(self, mock_db, invoice_tool):
        """Test vendor validation when vendor not found"""
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        mock_session.query.return_value.filter.return_value.first.return_value = None
        
        result = invoice_tool._validate_vendor("invalid-vendor")
        
        assert result["valid"] is False
        assert "not found" in result["message"].lower()
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_validate_vendor_blacklisted(self, mock_db, invoice_tool, sample_vendor):
        """Test vendor validation when vendor is blacklisted"""
        sample_vendor.is_blacklisted = True
        
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        mock_session.query.return_value.filter.return_value.first.return_value = sample_vendor
        
        result = invoice_tool._validate_vendor("vendor-123")
        
        assert result["valid"] is False
        assert "blacklisted" in result["message"].lower()
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_match_purchase_order_success(self, mock_db, invoice_tool, sample_invoice_data, sample_po):
        """Test successful PO matching"""
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        mock_session.query.return_value.filter.return_value.first.return_value = sample_po
        
        result = invoice_tool._match_purchase_order(sample_invoice_data)
        
        assert result["matched"] is True
        assert result["po_id"] == "po-123"
        assert result["confidence"] > 0.9
    
    @pytest.mark.integration
    @patch('database.get_db_context')
    def test_match_purchase_order_amount_mismatch(self, mock_db, invoice_tool, sample_po):
        """Test PO matching with amount mismatch"""
        invoice_data = {
            "vendor_id": "vendor-123",
            "po_number": "PO-2025-100",
            "amount": 10000.00  # Mismatch with PO amount
        }
        
        mock_session = Mock()
        mock_db.return_value.__enter__.return_value = mock_session
        mock_session.query.return_value.filter.return_value.first.return_value = sample_po
        
        result = invoice_tool._match_purchase_order(invoice_data)
        
        assert result["matched"] is False
        assert "amount mismatch" in result.get("reason", "").lower()


@pytest.mark.asyncio
class TestInvoiceAPI:
    """Test invoice API endpoints"""
    
    @pytest.mark.api
    async def test_create_invoice_endpoint(self):
        """Test invoice creation API"""
        # This would use FastAPI TestClient
        # Placeholder for actual implementation
        pass
    
    @pytest.mark.api
    async def test_list_invoices_endpoint(self):
        """Test invoice listing API"""
        pass


if __name__ == "__main__":
    pytest.main([__file__, "-v"])