# app/finsy_service.py
import os
import uuid
import json
import datetime
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from utils import init_db, save_invoice_record, get_invoice, save_approval, update_approval, summary_report
from joblib import load

app = Flask(__name__, template_folder='templates')
CORS(app)

DB_PATH = os.environ.get("FINSY_DB", "app/db/finsy.db")
MODEL_PATH = os.environ.get("RISK_MODEL", "app/models/risk_model.pkl")

# initialize DB
init_db(DB_PATH)

# Try load model if present
risk_model = None
try:
    risk_model = load(MODEL_PATH)
    print("[MODEL] Loaded risk model from", MODEL_PATH)
except Exception as e:
    print("[MODEL] no model found or load failed:", e)

##########################
# Invoice parsing endpoint
##########################
def parse_invoice_from_file(file_storage):
    """
    Placeholder parser: in production, call Document AI / Textract etc.
    Here we return a mock parsed invoice using filename heuristics.
    """
    filename = file_storage.filename
    invoice_id = str(uuid.uuid4())[:8]
    parsed = {
        "invoice_id": invoice_id,
        "vendor": "Acme Supplies",
        "date": datetime.date.today().isoformat(),
        "total": 12450.0,
        "currency": "USD",
        "po_number": "PO-789",
        "confidence": 0.92,
        "line_items": [{"description":"Widgets","qty":10,"price":1245.0}]
    }
    # persist minimal record
    save_invoice_record(DB_PATH, parsed, raw_file_name=filename)
    return parsed

@app.route("/invoices/parse", methods=["POST"])
def invoices_parse():
    if 'file' not in request.files:
        return jsonify({"error":"file required"}), 400
    f = request.files['file']
    parsed = parse_invoice_from_file(f)
    return jsonify(parsed)

##########################
# Risk scoring endpoint
##########################
def rule_based_features(inv):
    features = {}
    features['amount'] = inv.get('total', 0)
    features['has_po'] = 1 if inv.get('po_number') else 0
    # vendor suspiciousness simple heuristic
    features['vendor_suspicious'] = 1 if 'suspicious' in inv.get('vendor','').lower() else 0
    return features

def compute_risk_with_model(inv):
    if not risk_model:
        return None
    # create a fixed feature vector order
    feats = rule_based_features(inv)
    X = [[feats['amount'], feats['has_po'], feats['vendor_suspicious']]]
    score = float(risk_model.predict_proba(X)[0,1])
    return score

@app.route("/risk/score", methods=["POST"])
def risk_score():
    invoice = request.json
    if not invoice:
        return jsonify({"error":"invoice JSON required"}), 400
    # rule-based base score
    score = 0.0
    reasons = []
    if invoice.get("total", 0) > 50000:
        score += 0.6
        reasons.append("Amount above threshold")
    if not invoice.get("po_number"):
        score += 0.2
        reasons.append("Missing PO")
    if 'suspicious' in invoice.get("vendor","").lower():
        score += 0.3
        reasons.append("Vendor flagged suspicious")

    # model adjustment if available
    model_score = compute_risk_with_model(invoice)
    if model_score is not None:
        # mix rule-based and model (weighted)
        score = 0.4 * score + 0.6 * model_score

    score = min(1.0, max(0.0, score))
    level = "low"
    if score >= 0.7:
        level = "high"
    elif score >= 0.3:
        level = "medium"
    action = "auto-approve" if score < 0.3 else "route-for-review"

    result = {
        "invoice_id": invoice.get("invoice_id"),
        "score": round(score,3),
        "level": level,
        "reasons": reasons,
        "suggest_action": action
    }
    return jsonify(result)

##########################
# Approval endpoints
##########################
@app.route("/approvals/create", methods=["POST"])
def approvals_create():
    body = request.json
    if not body:
        return jsonify({"error":"approval body required"}), 400
    approval_id = str(uuid.uuid4())[:8]
    record = {
        "approval_id": approval_id,
        "invoice_id": body.get("invoice_id"),
        "requester": body.get("requester"),
        "approver": body.get("approver"),
        "reason": body.get("reason"),
        "status": "pending",
        "created_at": datetime.datetime.utcnow().isoformat()
    }
    save_approval(DB_PATH, record)
    # In production: send Slack/Teams message with action buttons, link to Orchestrate human-in-loop card
    return jsonify({"approval_id": approval_id, "status": "pending", "link": f"/approvals/{approval_id}"})

@app.route("/approvals/<approval_id>/action", methods=["POST"])
def approvals_action(approval_id):
    body = request.json
    action = body.get("action")
    comment = body.get("comment","")
    if action not in ("approve","reject"):
        return jsonify({"error":"invalid action"}), 400
    updated = update_approval(DB_PATH, approval_id, action, comment)
    if not updated:
        return jsonify({"error":"approval not found"}), 404
    # In production: callback to Orchestrate webhook to continue flow
    return jsonify(updated)

@app.route("/approvals/<approval_id>", methods=["GET"])
def approvals_view(approval_id):
    # simple HTML approval card for demo
    from utils import get_approval
    a = get_approval(DB_PATH, approval_id)
    if not a:
        return "Not found", 404
    return render_template("approval_card.html", approval=a)

##########################
# Reporting endpoint
##########################
@app.route("/reports/summary", methods=["GET"])
def reports_summary():
    start = request.args.get("start_date")
    end = request.args.get("end_date")
    report = summary_report(DB_PATH, start, end)
    return jsonify(report)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
