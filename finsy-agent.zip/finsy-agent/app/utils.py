# app/utils.py
import sqlite3
import os
import json
import datetime

def init_db(db_path):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS invoices (
      invoice_id TEXT PRIMARY KEY,
      vendor TEXT,
      date TEXT,
      total REAL,
      currency TEXT,
      po_number TEXT,
      confidence REAL,
      raw_file TEXT,
      created_at TEXT
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS approvals (
      approval_id TEXT PRIMARY KEY,
      invoice_id TEXT,
      requester TEXT,
      approver TEXT,
      reason TEXT,
      status TEXT,
      comment TEXT,
      created_at TEXT,
      updated_at TEXT
    )""")
    conn.commit()
    conn.close()

def save_invoice_record(db_path, invoice, raw_file_name=None):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    now = datetime.datetime.utcnow().isoformat()
    c.execute("INSERT OR REPLACE INTO invoices(invoice_id, vendor, date, total, currency, po_number, confidence, raw_file, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
              (invoice['invoice_id'], invoice.get('vendor'), invoice.get('date'), invoice.get('total'), invoice.get('currency'), invoice.get('po_number'), invoice.get('confidence'), raw_file_name, now))
    conn.commit()
    conn.close()

def get_invoice(db_path, invoice_id):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT invoice_id, vendor, date, total, currency, po_number, confidence FROM invoices WHERE invoice_id = ?", (invoice_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    keys = ['invoice_id','vendor','date','total','currency','po_number','confidence']
    return dict(zip(keys, row))

def save_approval(db_path, approval_record):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    now = datetime.datetime.utcnow().isoformat()
    c.execute("INSERT INTO approvals(approval_id, invoice_id, requester, approver, reason, status, created_at) VALUES (?,?,?,?,?,?,?)",
              (approval_record['approval_id'], approval_record['invoice_id'], approval_record['requester'], approval_record['approver'], approval_record['reason'], approval_record['status'], now))
    conn.commit()
    conn.close()

def update_approval(db_path, approval_id, action, comment):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    status = "approved" if action == "approve" else "rejected"
    now = datetime.datetime.utcnow().isoformat()
    c.execute("UPDATE approvals SET status=?, comment=?, updated_at=? WHERE approval_id=?", (status, comment, now, approval_id))
    conn.commit()
    c.execute("SELECT approval_id, invoice_id, requester, approver, reason, status, comment, created_at, updated_at FROM approvals WHERE approval_id=?", (approval_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    keys = ['approval_id','invoice_id','requester','approver','reason','status','comment','created_at','updated_at']
    return dict(zip(keys,row))

def get_approval(db_path, approval_id):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT approval_id, invoice_id, requester, approver, reason, status, comment, created_at, updated_at FROM approvals WHERE approval_id=?", (approval_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    keys = ['approval_id','invoice_id','requester','approver','reason','status','comment','created_at','updated_at']
    return dict(zip(keys,row))

def summary_report(db_path, start_date=None, end_date=None):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    q = "SELECT count(*) FROM invoices"
    c.execute(q)
    total_invoices = c.fetchone()[0]
    c.execute("SELECT count(*) FROM approvals WHERE status='approved'")
    approved = c.fetchone()[0]
    c.execute("SELECT count(*) FROM approvals WHERE status='pending'")
    pending = c.fetchone()[0]
    conn.close()
    return {
        "total_invoices": total_invoices,
        "approved_approvals": approved,
        "pending_approvals": pending,
        "period": {"start": start_date, "end": end_date}
    }
